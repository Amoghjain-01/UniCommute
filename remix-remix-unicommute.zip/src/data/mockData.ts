import { 
  BusRoute, 
  LiveBus, 
  TrafficCluster, 
  TrafficReport, 
  CarpoolRide, 
  DelayAttendanceClaim, 
  LiveStreamSession, 
  StudyResource, 
  UserProfile 
} from '../types';

// Default Demo User Accounts
export const DEMO_PROFILES: Record<string, UserProfile> = {
  student: {
    id: 'usr-student-01',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@university.edu',
    role: 'student',
    institutionalId: 'STU-2026-8942',
    department: 'Dept. of Computer Science & Engineering',
    verifiedIdCard: true,
    idCardData: {
      barcodeId: 'UNI-CS-8942-A',
      validThrough: '2027-06-30',
      verifiedAt: '2026-01-15T09:30:00Z',
    },
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    phoneNumber: '+91 98765 43210'
  },
  faculty: {
    id: 'usr-fac-02',
    name: 'Dr. Radhika Sen',
    email: 'r.sen@university.edu',
    role: 'faculty',
    institutionalId: 'FAC-ENG-402',
    department: 'School of Advanced Computing',
    verifiedIdCard: true,
    idCardData: {
      barcodeId: 'FAC-402-ACAD',
      validThrough: '2029-12-31',
      verifiedAt: '2025-08-01T10:00:00Z',
    },
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    phoneNumber: '+91 98450 11223'
  },
  driver: {
    id: 'usr-drv-03',
    name: 'Vikram Pal (Bus 14)',
    email: 'fleet.vpal@university.edu',
    role: 'driver',
    institutionalId: 'DRV-FLEET-104',
    department: 'University Transit & Transportation Logistics',
    verifiedIdCard: true,
    idCardData: {
      barcodeId: 'TRANSIT-DRV-104',
      validThrough: '2028-05-15',
      verifiedAt: '2025-11-10T08:00:00Z',
    },
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    phoneNumber: '+91 94480 99887'
  }
};

// University Map Coordinates Center (Tech Campus Corridor)
export const CAMPUS_CENTER = {
  lat: 12.9716,
  lng: 77.5946,
  zoom: 14
};

// University Bus Routes
export const INITIAL_ROUTES: BusRoute[] = [
  {
    id: 'route-blue-01',
    name: 'Route 1: North Metro Express',
    code: 'R1-METRO',
    color: '#3b82f6', // Blue
    operatingHours: '06:30 AM - 09:30 PM',
    frequencyMin: 12,
    stops: [
      { id: 'stop-101', name: 'North Metro Interchange Hub', lat: 12.9850, lng: 77.5800, sequence: 1, landmark: 'Gate 2 Metro Entrance' },
      { id: 'stop-102', name: 'Residency Road Junction', lat: 12.9780, lng: 77.5870, sequence: 2, landmark: 'Opposite Public Library' },
      { id: 'stop-103', name: 'Tech Park Commuter Bay', lat: 12.9730, lng: 77.5920, sequence: 3, landmark: 'Tower C Canopy' },
      { id: 'stop-104', name: 'University Main Gate Terminal', lat: 12.9680, lng: 77.5990, sequence: 4, landmark: 'Admin Arch' },
      { id: 'stop-105', name: 'Engineering & Computing Quad', lat: 12.9650, lng: 77.6040, sequence: 5, landmark: 'Turing Hall East' }
    ],
    pathCoordinates: [
      [12.9850, 77.5800],
      [12.9815, 77.5835],
      [12.9780, 77.5870],
      [12.9755, 77.5895],
      [12.9730, 77.5920],
      [12.9705, 77.5955],
      [12.9680, 77.5990],
      [12.9665, 77.6015],
      [12.9650, 77.6040]
    ]
  },
  {
    id: 'route-emerald-02',
    name: 'Route 2: Green Hills & Science Ring',
    code: 'R2-SCIENCE',
    color: '#10b981', // Emerald
    operatingHours: '07:00 AM - 08:30 PM',
    frequencyMin: 15,
    stops: [
      { id: 'stop-201', name: 'South Suburban Station', lat: 12.9550, lng: 77.5820, sequence: 1, landmark: 'Platform 1 Bay' },
      { id: 'stop-202', name: 'Bio-Medical Campus Crossing', lat: 12.9600, lng: 77.5900, sequence: 2, landmark: 'Hospital North Circle' },
      { id: 'stop-203', name: 'Central Library Roundabout', lat: 12.9670, lng: 77.5960, sequence: 3, landmark: 'Clock Tower' },
      { id: 'stop-204', name: 'Graduate Research Center', lat: 12.9720, lng: 77.6020, sequence: 4, landmark: 'Innovation Hub' }
    ],
    pathCoordinates: [
      [12.9550, 77.5820],
      [12.9575, 77.5860],
      [12.9600, 77.5900],
      [12.9635, 77.5930],
      [12.9670, 77.5960],
      [12.9695, 77.5990],
      [12.9720, 77.6020]
    ]
  },
  {
    id: 'route-amber-03',
    name: 'Route 3: East Faculty & Hostel Link',
    code: 'R3-EAST',
    color: '#f59e0b', // Amber
    operatingHours: '06:45 AM - 10:00 PM',
    frequencyMin: 20,
    stops: [
      { id: 'stop-301', name: 'East Lake Hostels & Apartments', lat: 12.9820, lng: 77.6120, sequence: 1, landmark: 'Hostel Block 4 Bay' },
      { id: 'stop-302', name: 'Faculty Quarters Gate 4', lat: 12.9760, lng: 77.6080, sequence: 2, landmark: 'Post Office' },
      { id: 'stop-303', name: 'University Sports Complex', lat: 12.9700, lng: 77.6030, sequence: 3, landmark: 'Stadium West' },
      { id: 'stop-304', name: 'Student Union Hub', lat: 12.9660, lng: 77.5980, sequence: 4, landmark: 'Cafeteria Plaza' }
    ],
    pathCoordinates: [
      [12.9820, 77.6120],
      [12.9790, 77.6100],
      [12.9760, 77.6080],
      [12.9730, 77.6055],
      [12.9700, 77.6030],
      [12.9680, 77.6005],
      [12.9660, 77.5980]
    ]
  }
];

// Initial Live Buses
export const INITIAL_BUSES: LiveBus[] = [
  {
    id: 'bus-14',
    routeId: 'route-blue-01',
    routeName: 'Route 1: North Metro Express',
    routeColor: '#3b82f6',
    busNumber: 'KA-01-EQ-1420',
    driverName: 'Vikram Pal',
    driverId: 'usr-drv-03',
    lat: 12.9760,
    lng: 77.5885,
    speedKmH: 34,
    headingDeg: 140,
    nextStopId: 'stop-103',
    nextStopName: 'Tech Park Commuter Bay',
    etaNextStopMin: 4,
    capacity: 52,
    occupancy: 38,
    lastPingUtc: new Date().toISOString(),
    isBroadcasting: true,
    status: 'ON_TIME'
  },
  {
    id: 'bus-08',
    routeId: 'route-emerald-02',
    routeName: 'Route 2: Green Hills & Science Ring',
    routeColor: '#10b981',
    busNumber: 'KA-01-EQ-0811',
    driverName: 'Manish Rawat',
    driverId: 'usr-drv-08',
    lat: 12.9630,
    lng: 77.5925,
    speedKmH: 18,
    headingDeg: 45,
    nextStopId: 'stop-203',
    nextStopName: 'Central Library Roundabout',
    etaNextStopMin: 7,
    capacity: 45,
    occupancy: 41,
    lastPingUtc: new Date().toISOString(),
    isBroadcasting: true,
    status: 'DELAYED_TRAFFIC'
  },
  {
    id: 'bus-22',
    routeId: 'route-amber-03',
    routeName: 'Route 3: East Faculty & Hostel Link',
    routeColor: '#f59e0b',
    busNumber: 'KA-01-EQ-2204',
    driverName: 'Harpreet Singh',
    driverId: 'usr-drv-22',
    lat: 12.9740,
    lng: 77.6065,
    speedKmH: 28,
    headingDeg: 210,
    nextStopId: 'stop-303',
    nextStopName: 'University Sports Complex',
    etaNextStopMin: 5,
    capacity: 50,
    occupancy: 22,
    lastPingUtc: new Date().toISOString(),
    isBroadcasting: true,
    status: 'ON_TIME'
  }
];

// Initial Traffic Incidents & Consensus Clusters
export const INITIAL_TRAFFIC_CLUSTERS: TrafficCluster[] = [
  {
    id: 'cluster-jam-residency',
    incidentType: 'JAM',
    lat: 12.9775,
    lng: 77.5878,
    locationName: 'Residency Road Flyover Descent',
    radiusMeters: 220,
    reportCount: 3,
    requiredReports: 3,
    verified: true, // >= 3 reports within 300m in 15min
    reports: [
      {
        id: 'rep-01',
        reporterId: 'stu-10',
        reporterName: 'Neha Verma',
        reporterRole: 'student',
        reporterEmail: 'neha.v@university.edu',
        incidentType: 'JAM',
        description: 'Bumper-to-bumper standstill near flyover exit. 25+ min delay.',
        lat: 12.9772,
        lng: 77.5875,
        locationName: 'Flyover ramp',
        timestampUtc: new Date(Date.now() - 8 * 60 * 1000).toISOString()
      },
      {
        id: 'rep-02',
        reporterId: 'drv-03',
        reporterName: 'Vikram Pal (Driver)',
        reporterRole: 'driver',
        reporterEmail: 'fleet.vpal@university.edu',
        incidentType: 'JAM',
        description: 'Heavy congestion due to broken down water tanker blocking 2 lanes.',
        lat: 12.9776,
        lng: 77.5879,
        locationName: 'Residency Road junction',
        timestampUtc: new Date(Date.now() - 6 * 60 * 1000).toISOString()
      },
      {
        id: 'rep-03',
        reporterId: 'fac-09',
        reporterName: 'Prof. Ananya Roy',
        reporterRole: 'faculty',
        reporterEmail: 'ananya.roy@university.edu',
        incidentType: 'JAM',
        description: 'Stuck on Route 1 path. Cars moving less than 5 km/h.',
        lat: 12.9778,
        lng: 77.5880,
        locationName: 'Opp. Public Library',
        timestampUtc: new Date(Date.now() - 2 * 60 * 1000).toISOString()
      }
    ],
    firstReportedAt: new Date(Date.now() - 8 * 60 * 1000).toISOString(),
    lastReportedAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
    affectedRoutes: ['route-blue-01'],
    detourSuggested: 'Divert via Church Street Underpass to bypass 20 min choke',
    severity: 'CRITICAL'
  },
  {
    id: 'cluster-roadblock-science',
    incidentType: 'ROADBLOCK',
    lat: 12.9610,
    lng: 77.5910,
    locationName: 'Hospital North Circle Pipeline Repair',
    radiusMeters: 180,
    reportCount: 2, // 2 reports -> PENDING verification (needs 1 more)
    requiredReports: 3,
    verified: false,
    reports: [
      {
        id: 'rep-04',
        reporterId: 'stu-22',
        reporterName: 'Karan Patel',
        reporterRole: 'student',
        reporterEmail: 'karan.p@university.edu',
        incidentType: 'ROADBLOCK',
        description: 'Barricades set up for municipal pipe digging. One way traffic.',
        lat: 12.9608,
        lng: 77.5908,
        locationName: 'Hospital Circle East',
        timestampUtc: new Date(Date.now() - 5 * 60 * 1000).toISOString()
      },
      {
        id: 'rep-05',
        reporterId: 'stu-31',
        reporterName: 'Pooja Iyer',
        reporterRole: 'student',
        reporterEmail: 'pooja.i@university.edu',
        incidentType: 'ROADBLOCK',
        description: 'Road blocked from circle to Bio-Med crossing.',
        lat: 12.9612,
        lng: 77.5912,
        locationName: 'Bio-Med crossing lane',
        timestampUtc: new Date(Date.now() - 3 * 60 * 1000).toISOString()
      }
    ],
    firstReportedAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    lastReportedAt: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
    affectedRoutes: ['route-emerald-02'],
    detourSuggested: 'Use Ring Road South bypass',
    severity: 'MEDIUM'
  }
];

// Initial Carpools with strict ₹ Indian Rupee equal split calculation
export const INITIAL_CARPOOLS: CarpoolRide[] = [
  {
    id: 'ride-cp-101',
    driverId: 'usr-fac-02',
    driverName: 'Dr. Radhika Sen',
    driverEmail: 'r.sen@university.edu',
    driverRole: 'faculty',
    driverRating: 4.9,
    vehicleModel: 'Honda City (White) • Hybrid',
    vehiclePlate: 'KA-04-MB-8821',
    origin: 'Koramangala 4th Block Club',
    destination: 'Engineering & Computing Quad Gate 2',
    departureTime: '08:15 AM',
    totalSeats: 4,
    availableSeats: 2,
    totalFuelCostINR: 360, // Total estimated fuel + toll in ₹
    perSeatCostINR: 120, // 360 / (1 driver + 2 confirmed riders) = ₹120 per passenger
    safetyPin: '4829',
    status: 'OPEN',
    notes: 'Non-smoking, AC on, quiet study friendly ride. Leaves sharp at 8:15 AM.',
    riders: [
      {
        id: 'rdr-01',
        userId: 'stu-77',
        userName: 'Rohan Gupta',
        userEmail: 'rohan.g@university.edu',
        userRole: 'student',
        seatsBooked: 1,
        farePaidINR: 120,
        pickupLocation: 'Sony World Junction Bus Stop',
        bookedAt: '2026-08-22T07:10:00Z'
      },
      {
        id: 'rdr-02',
        userId: 'stu-88',
        userName: 'Ananya Deshmukh',
        userEmail: 'ananya.d@university.edu',
        userRole: 'student',
        seatsBooked: 1,
        farePaidINR: 120,
        pickupLocation: 'Forum Mall South Gate',
        bookedAt: '2026-08-22T07:25:00Z'
      }
    ]
  },
  {
    id: 'ride-cp-102',
    driverId: 'stu-99',
    driverName: 'Devansh Kulkarni',
    driverEmail: 'devansh.k@university.edu',
    driverRole: 'student',
    driverRating: 4.8,
    vehicleModel: 'Hyundai i20 (Silver)',
    vehiclePlate: 'KA-03-NJ-4190',
    origin: 'Indiranagar 100ft Road Metro',
    destination: 'Central Campus Library Parking Bay',
    departureTime: '08:30 AM',
    totalSeats: 3,
    availableSeats: 1,
    totalFuelCostINR: 280,
    perSeatCostINR: 93, // 280 / 3 = ₹93
    safetyPin: '9134',
    status: 'OPEN',
    notes: 'Playing lofi beats, space in trunk for backpack/laptops.',
    riders: [
      {
        id: 'rdr-03',
        userId: 'stu-33',
        userName: 'Simran Chadha',
        userEmail: 'simran.c@university.edu',
        userRole: 'student',
        seatsBooked: 1,
        farePaidINR: 93,
        pickupLocation: 'Domlur Flyover Bus Bay',
        bookedAt: '2026-08-22T07:40:00Z'
      }
    ]
  },
  {
    id: 'ride-cp-103',
    driverId: 'fac-55',
    driverName: 'Prof. Suresh Nair',
    driverEmail: 'suresh.nair@university.edu',
    driverRole: 'faculty',
    driverRating: 5.0,
    vehicleModel: 'Tata Nexon EV (Teal Blue)',
    vehiclePlate: 'KA-05-EV-1902',
    origin: 'HSR Layout Sector 2 BDA Complex',
    destination: 'School of Advanced Computing',
    departureTime: '08:00 AM',
    totalSeats: 4,
    availableSeats: 3,
    totalFuelCostINR: 200, // EV charging share
    perSeatCostINR: 100, // 200 / 2 = ₹100
    safetyPin: '6312',
    status: 'OPEN',
    notes: 'Green EV commute! Zero emissions to campus.',
    riders: [
      {
        id: 'rdr-04',
        userId: 'stu-61',
        userName: 'Tanvi Joshi',
        userEmail: 'tanvi.j@university.edu',
        userRole: 'student',
        seatsBooked: 1,
        farePaidINR: 100,
        pickupLocation: 'Silk Board Metro Bridge',
        bookedAt: '2026-08-22T07:30:00Z'
      }
    ]
  }
];

// Initial Delay Attendance Claims
export const INITIAL_ATTENDANCE_CLAIMS: DelayAttendanceClaim[] = [
  {
    id: 'claim-att-901',
    studentId: 'usr-student-01',
    studentName: 'Aarav Sharma',
    studentEmail: 'aarav.sharma@university.edu',
    studentInstitutionalId: 'STU-2026-8942',
    courseCode: 'CS-401',
    courseName: 'Distributed Cloud Systems & Microservices',
    professorId: 'usr-fac-02',
    professorName: 'Dr. Radhika Sen',
    classStartTime: '09:00 AM',
    capturedTimestampUtc: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
    capturedGps: {
      lat: 12.9774,
      lng: 77.5877,
      accuracyMeters: 4.8
    },
    locationAddress: 'Residency Road Flyover Descent (Near Public Library)',
    recordedVideoUrl: 'blob:simulated-in-app-video-watermarked',
    capturedPhotoBase64: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&auto=format&fit=crop&q=80',
    estimatedDelayMin: 35,
    excuseReason: 'University Route 1 bus is trapped behind water tanker accident on Residency Road flyover.',
    trafficProximityScore: 98, // 98% correlation to verified hazard
    nearestVerifiedHazard: {
      clusterId: 'cluster-jam-residency',
      incidentType: 'JAM',
      distanceMeters: 38,
      locationName: 'Residency Road Flyover Descent'
    },
    status: 'PENDING'
  },
  {
    id: 'claim-att-882',
    studentId: 'stu-54',
    studentName: 'Priya Mehra',
    studentEmail: 'priya.m@university.edu',
    studentInstitutionalId: 'STU-2026-4419',
    courseCode: 'CS-401',
    courseName: 'Distributed Cloud Systems & Microservices',
    professorId: 'usr-fac-02',
    professorName: 'Dr. Radhika Sen',
    classStartTime: '09:00 AM',
    capturedTimestampUtc: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    capturedGps: {
      lat: 12.9771,
      lng: 77.5873,
      accuracyMeters: 5.2
    },
    locationAddress: 'Residency Rd Corridor',
    recordedVideoUrl: 'blob:simulated-in-app-video-watermarked',
    capturedPhotoBase64: 'https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?w=600&auto=format&fit=crop&q=80',
    estimatedDelayMin: 30,
    excuseReason: 'Stuck in Route 1 bus traffic jam with 40 other students.',
    trafficProximityScore: 96,
    nearestVerifiedHazard: {
      clusterId: 'cluster-jam-residency',
      incidentType: 'JAM',
      distanceMeters: 55,
      locationName: 'Residency Road Flyover Descent'
    },
    status: 'APPROVED',
    professorDecisionComment: 'Verified with consensus traffic incident on Route 1. Excused attendance granted.',
    reviewedAt: new Date(Date.now() - 15 * 60 * 1000).toISOString()
  }
];

// Initial Live Stream & Commute Study Hub
export const INITIAL_LIVE_STREAM: LiveStreamSession = {
  id: 'stream-cs401-live',
  courseCode: 'CS-401',
  courseName: 'Distributed Cloud Systems & Microservices',
  professorName: 'Dr. Radhika Sen',
  topicTitle: 'Lecture 14: Raft Consensus Protocol & Leader Election in Distributed Transit Systems',
  isLive: true,
  viewerCount: 48,
  startedAt: '09:00 AM',
  durationMinutes: 42,
  videoPlaybackUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
  liveTranscript: [
    { time: '09:05', speaker: 'Dr. Radhika Sen', text: 'Good morning everyone in class and those tuning in on the UniCommute live commute stream.' },
    { time: '09:08', speaker: 'Dr. Radhika Sen', text: 'Today we explore how consensus algorithms solve split-brain problems in distributed node networks.' },
    { time: '09:15', speaker: 'Dr. Radhika Sen', text: 'Notice how a leader node maintains term heartbeats every 150-300ms to prevent timeout election triggers.' },
    { time: '09:22', speaker: 'Dr. Radhika Sen', text: 'Similar to our campus traffic consensus edge logic, a candidate node must receive majority vote quorum before committing state logs.' },
    { time: '09:34', speaker: 'Dr. Radhika Sen', text: 'Look at slide 18: when a log entry is replicated across (N/2 + 1) servers, it is safe to commit.' }
  ],
  aiSummaryNotes: [
    'Raft achieves consensus via leader election, log replication, and state safety guarantees.',
    'Quorum rule: requires majority confirmation (N/2 + 1) before log state changes commit.',
    'Heartbeat timeouts (150-300ms randomized) prevent split-vote deadlocks during network partitions.',
    'Commute students: Homework 3 on Raft RPC simulation is due Friday midnight.'
  ],
  keyDefinitions: [
    { term: 'Split-Brain', definition: 'A condition where two parts of a cluster believe they are the authoritative primary leader.' },
    { term: 'Quorum', definition: 'The minimum number of members required to approve state transitions (strictly > 50%).' },
    { term: 'Term Number', definition: 'Logical clock counter incremented on every new leader election phase.' }
  ]
};

// Initial Study Resources
export const INITIAL_STUDY_RESOURCES: StudyResource[] = [
  {
    id: 'res-101',
    courseCode: 'CS-401',
    courseName: 'Distributed Cloud Systems',
    title: 'Raft & Paxos Consensus Cheat-Sheet with Architecture Diagrams',
    type: 'SUMMARY_CHEAT_SHEET',
    authorName: 'Aarav Sharma (TA)',
    authorRole: 'student',
    uploadDate: '2026-08-20',
    downloadsCount: 142,
    upvotes: 68,
    durationOrPages: '6 Pages PDF',
    description: 'Concise visual guide explaining election timeouts, log entries, and follower repair protocols.',
    contentMarkdown: '# Raft Consensus Protocol Breakdown\n\n## 1. Leader Election\n- Random election timer between 150ms and 300ms\n- If no heartbeat received, convert to Candidate\n- RequestVote RPC to all peers\n\n## 2. Log Replication\n- AppendEntries RPC from Leader\n- Committed once stored on majority'
  },
  {
    id: 'res-102',
    courseCode: 'CS-401',
    courseName: 'Distributed Cloud Systems',
    title: 'Commute Audio Podcast: Distributed Systems Architecture (Episode 4)',
    type: 'AUDIO_PODCAST',
    authorName: 'Dr. Radhika Sen',
    authorRole: 'faculty',
    uploadDate: '2026-08-18',
    downloadsCount: 215,
    upvotes: 95,
    durationOrPages: '18 min Audio',
    description: 'Listen while in transit! Audio walkthrough of Byzantine fault tolerance, CAP theorem tradeoffs, and edge clustering.',
    contentMarkdown: 'Podcast Episode 4 Audio summary for bus & metro commuters.'
  },
  {
    id: 'res-103',
    courseCode: 'MATH-202',
    courseName: 'Linear Algebra & Optimization',
    title: 'Midterm 2 Solved Questions & Eigenvalue Decomposition Handouts',
    type: 'PDF_NOTES',
    authorName: 'Prof. Suresh Nair',
    authorRole: 'faculty',
    uploadDate: '2026-08-21',
    downloadsCount: 310,
    upvotes: 124,
    durationOrPages: '14 Pages PDF',
    description: 'Detailed stepwise derivations for Singular Value Decomposition and Principal Component Analysis.'
  }
];

export const INITIAL_COURSES = [
  { code: 'CS-401', name: 'Distributed Cloud Systems & Microservices', professor: 'Dr. Radhika Sen', department: 'Computer Science', schedule: 'MWF 09:00 - 10:15 AM', room: 'Turing Hall 102' },
  { code: 'CS-302', name: 'Database Engineering & Concurrency Control', professor: 'Prof. Suresh Nair', department: 'Computer Science', schedule: 'TTh 10:30 - 11:45 AM', room: 'Babbage Lab 304' },
  { code: 'ECE-210', name: 'Embedded Systems & IoT Sensors', professor: 'Dr. Amitabh Roy', department: 'Electrical Eng', schedule: 'MWF 11:30 - 12:45 PM', room: 'Tesla Wing 201' },
  { code: 'MATH-202', name: 'Linear Algebra & Optimization', professor: 'Dr. Priya Nambiar', department: 'Mathematics', schedule: 'TTh 02:00 - 03:15 PM', room: 'Ramanujan Hall' }
];
