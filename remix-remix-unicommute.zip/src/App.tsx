import React, { useState, useEffect, useRef } from 'react';
import { 
  UserProfile, 
  UserRole, 
  ActiveFeatureView, 
  BusRoute, 
  LiveBus, 
  TrafficCluster, 
  TrafficReport, 
  CarpoolRide, 
  DelayAttendanceClaim, 
  LiveStreamSession, 
  StudyResource 
} from './types';
import { 
  DEMO_PROFILES, 
  INITIAL_ROUTES, 
  INITIAL_BUSES, 
  INITIAL_TRAFFIC_CLUSTERS, 
  INITIAL_CARPOOLS, 
  INITIAL_ATTENDANCE_CLAIMS, 
  INITIAL_LIVE_STREAM, 
  INITIAL_STUDY_RESOURCES 
} from './data/mockData';

// Components
import { Navbar } from './components/Navbar';
import { HomePortal } from './components/HomePortal';
import { BusTrackerView } from './components/BusTrackerView';
import { TrafficConsensusView } from './components/TrafficConsensusView';
import { CarpoolView } from './components/CarpoolView';
import { AttendanceVerificationView } from './components/AttendanceVerificationView';
import { StudyStreamView } from './components/StudyStreamView';
import { IdOcrModal } from './components/IdOcrModal';
import { DbSchemaModal } from './components/DbSchemaModal';

export default function App() {
  // Navigation & View State
  const [currentView, setCurrentView] = useState<ActiveFeatureView>('HOME_PORTAL');
  
  // User Authentication & Role State (locked to @university.edu)
  const [currentUser, setCurrentUser] = useState<UserProfile>(DEMO_PROFILES.student);
  const [showIdScannerModal, setShowIdScannerModal] = useState<boolean>(false);
  const [showDbSchemaModal, setShowDbSchemaModal] = useState<boolean>(false);

  // Application Data State
  const [routes, setRoutes] = useState<BusRoute[]>(INITIAL_ROUTES);
  const [buses, setBuses] = useState<LiveBus[]>(INITIAL_BUSES);
  const [trafficClusters, setTrafficClusters] = useState<TrafficCluster[]>(INITIAL_TRAFFIC_CLUSTERS);
  const [allReports, setAllReports] = useState<TrafficReport[]>([]);
  const [carpools, setCarpools] = useState<CarpoolRide[]>(INITIAL_CARPOOLS);
  const [attendanceClaims, setAttendanceClaims] = useState<DelayAttendanceClaim[]>(INITIAL_ATTENDANCE_CLAIMS);
  const [studyResources, setStudyResources] = useState<StudyResource[]>(INITIAL_STUDY_RESOURCES);
  const [liveStream, setLiveStream] = useState<LiveStreamSession>(INITIAL_LIVE_STREAM);

  // WebSocket Connection State
  const [isWsConnected, setIsWsConnected] = useState<boolean>(false);
  const wsRef = useRef<WebSocket | null>(null);

  // Initialize and Maintain WebSocket Connection
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/transit`;
    
    let ws: WebSocket;
    try {
      ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsWsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          if (message.type === 'INITIAL_STATE') {
            if (message.data.buses) setBuses(message.data.buses);
            if (message.data.trafficClusters) setTrafficClusters(message.data.trafficClusters);
            if (message.data.carpools) setCarpools(message.data.carpools);
            if (message.data.attendanceClaims) setAttendanceClaims(message.data.attendanceClaims);
          } else if (message.type === 'BUS_UPDATED') {
            const updatedBus: LiveBus = message.payload;
            setBuses(prev => prev.map(b => b.id === updatedBus.id ? updatedBus : b));
          } else if (message.type === 'TRAFFIC_UPDATED') {
            setTrafficClusters(message.payload.clusters);
            if (message.payload.latestReport) {
              setAllReports(prev => [message.payload.latestReport, ...prev]);
            }
          } else if (message.type === 'CARPOOL_UPDATED') {
            setCarpools(message.payload);
          } else if (message.type === 'ATTENDANCE_UPDATED') {
            setAttendanceClaims(message.payload);
          }
        } catch (err) {
          console.error('Error handling WS event:', err);
        }
      };

      ws.onclose = () => {
        setIsWsConnected(false);
      };
    } catch (err) {
      console.warn('WS not available, using REST fallback:', err);
    }

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  // Fetch initial data from REST API as fallback
  useEffect(() => {
    fetch('/api/transit/buses')
      .then(res => res.json())
      .then(data => { if (data.success) setBuses(data.buses); })
      .catch(() => {});

    fetch('/api/traffic/clusters')
      .then(res => res.json())
      .then(data => { if (data.success) setTrafficClusters(data.clusters); })
      .catch(() => {});

    fetch('/api/carpool/rides')
      .then(res => res.json())
      .then(data => { if (data.success) setCarpools(data.rides); })
      .catch(() => {});

    fetch('/api/attendance/claims')
      .then(res => res.json())
      .then(data => { if (data.success) setAttendanceClaims(data.claims); })
      .catch(() => {});
  }, []);

  // Role Switcher Handler
  const handleRoleChange = (role: UserRole) => {
    if (role === 'student') setCurrentUser(DEMO_PROFILES.student);
    else if (role === 'faculty') setCurrentUser(DEMO_PROFILES.faculty);
    else if (role === 'driver') setCurrentUser(DEMO_PROFILES.driver);
  };

  // Driver GPS Telemetry Ping Handler
  const handleDriverPing = async (busUpdate: Partial<LiveBus>) => {
    // Send via WebSocket if connected
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'DRIVER_GPS_TRANSMIT',
        payload: {
          busId: busUpdate.id,
          lat: busUpdate.lat,
          lng: busUpdate.lng,
          speedKmH: busUpdate.speedKmH,
          headingDeg: busUpdate.headingDeg,
          nextStopId: busUpdate.nextStopId,
          nextStopName: busUpdate.nextStopName,
          etaNextStopMin: busUpdate.etaNextStopMin,
          occupancy: busUpdate.occupancy
        }
      }));
    }

    // Also send via REST API
    try {
      await fetch('/api/transit/driver/ping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          busId: busUpdate.id,
          lat: busUpdate.lat,
          lng: busUpdate.lng,
          speedKmH: busUpdate.speedKmH,
          headingDeg: busUpdate.headingDeg,
          nextStopId: busUpdate.nextStopId,
          nextStopName: busUpdate.nextStopName,
          etaNextStopMin: busUpdate.etaNextStopMin,
          occupancy: busUpdate.occupancy
        })
      });
    } catch {}

    // Update local state immediately
    setBuses(prev => prev.map(b => b.id === busUpdate.id ? { ...b, ...busUpdate } as LiveBus : b));
  };

  // Traffic Incident Submission Handler
  const handleSubmitTrafficReport = async (reportData: Partial<TrafficReport>) => {
    try {
      const res = await fetch('/api/traffic/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reportData)
      });
      const data = await res.json();
      if (data.success) {
        setTrafficClusters(data.clusters);
        setAllReports(prev => [data.report, ...prev]);
      }
    } catch (err) {
      console.error('Report submission error:', err);
    }
  };

  // Carpool Creation Handler (in ₹ INR)
  const handleCreateCarpool = async (rideData: Partial<CarpoolRide>) => {
    try {
      const res = await fetch('/api/carpool/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rideData)
      });
      const data = await res.json();
      if (data.success) {
        setCarpools(prev => [data.ride, ...prev]);
      }
    } catch (err) {
      console.error('Carpool create error:', err);
    }
  };

  // Carpool Booking Handler (Dynamic Equal Split in ₹ INR)
  const handleBookCarpool = async (rideId: string, seats: number, pickup: string) => {
    try {
      const res = await fetch('/api/carpool/book', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rideId,
          userId: currentUser.id,
          userName: currentUser.name,
          userEmail: currentUser.email,
          userRole: currentUser.role,
          pickupLocation: pickup,
          seatsBooked: seats
        })
      });
      const data = await res.json();
      if (data.success) {
        setCarpools(prev => prev.map(r => r.id === rideId ? data.ride : r));
      }
    } catch (err) {
      console.error('Carpool book error:', err);
    }
  };

  // Delay Attendance Submission Handler
  const handleSubmitAttendanceClaim = async (claimData: Partial<DelayAttendanceClaim>) => {
    try {
      const res = await fetch('/api/attendance/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(claimData)
      });
      const data = await res.json();
      if (data.success) {
        setAttendanceClaims(prev => [data.claim, ...prev]);
      }
    } catch (err) {
      console.error('Attendance claim submit error:', err);
    }
  };

  // Professor Review Handler
  const handleReviewAttendanceClaim = async (claimId: string, decision: 'APPROVE' | 'REJECT', comment?: string) => {
    try {
      const res = await fetch('/api/attendance/review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claimId, decision, professorComment: comment })
      });
      const data = await res.json();
      if (data.success) {
        setAttendanceClaims(prev => prev.map(c => c.id === claimId ? data.claim : c));
      }
    } catch (err) {
      console.error('Attendance review error:', err);
    }
  };

  // Study Resource Upload Handler
  const handleUploadStudyResource = async (resData: Partial<StudyResource>) => {
    try {
      const res = await fetch('/api/study/resources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(resData)
      });
      const data = await res.json();
      if (data.success) {
        setStudyResources(prev => [data.resource, ...prev]);
      }
    } catch (err) {
      console.error('Upload resource error:', err);
    }
  };

  // ID Card Scan Success
  const handleIdVerifySuccess = (idData: any) => {
    setCurrentUser(prev => ({
      ...prev,
      verifiedIdCard: true,
      idCardData: idData
    }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased">
      {/* Navigation Header */}
      <Navbar
        currentView={currentView}
        onSelectView={(v) => {
          if (v === 'ID_OCR_MODAL') {
            setShowIdScannerModal(true);
          } else if (v === 'DB_SCHEMA_HUB') {
            setShowDbSchemaModal(true);
          } else {
            setCurrentView(v);
          }
        }}
        currentUser={currentUser}
        onRoleChange={handleRoleChange}
        onOpenIdScanner={() => setShowIdScannerModal(true)}
        isWsConnected={isWsConnected}
      />

      {/* Main View Router */}
      <main className="flex-1 pb-12">
        {currentView === 'HOME_PORTAL' && (
          <HomePortal
            onSelectFeature={(feature) => {
              if (feature === 'ID_OCR_MODAL') {
                setShowIdScannerModal(true);
              } else if (feature === 'DB_SCHEMA_HUB') {
                setShowDbSchemaModal(true);
              } else {
                setCurrentView(feature);
              }
            }}
            currentUser={currentUser}
            liveBuses={buses}
            trafficClusters={trafficClusters}
            carpools={carpools}
            attendanceClaims={attendanceClaims}
          />
        )}

        {currentView === 'BUS_TRACKER' && (
          <BusTrackerView
            routes={routes}
            buses={buses}
            trafficClusters={trafficClusters}
            currentUser={currentUser}
            onDriverPing={handleDriverPing}
            onSelectTrafficIncident={() => setCurrentView('TRAFFIC_CONSENSUS')}
          />
        )}

        {currentView === 'TRAFFIC_CONSENSUS' && (
          <TrafficConsensusView
            clusters={trafficClusters}
            allReports={allReports}
            currentUser={currentUser}
            onSubmitReport={handleSubmitTrafficReport}
          />
        )}

        {currentView === 'CARPOOL_INR' && (
          <CarpoolView
            rides={carpools}
            currentUser={currentUser}
            onCreateRide={handleCreateCarpool}
            onBookRide={handleBookCarpool}
          />
        )}

        {currentView === 'ATTENDANCE_DELAY' && (
          <AttendanceVerificationView
            claims={attendanceClaims}
            trafficClusters={trafficClusters}
            currentUser={currentUser}
            onSubmitClaim={handleSubmitAttendanceClaim}
            onReviewClaim={handleReviewAttendanceClaim}
          />
        )}

        {currentView === 'STUDY_STREAM' && (
          <StudyStreamView
            stream={liveStream}
            resources={studyResources}
            currentUser={currentUser}
            onUploadResource={handleUploadStudyResource}
          />
        )}
      </main>

      {/* Institutional ID Card OCR Modal */}
      <IdOcrModal
        currentUser={currentUser}
        isOpen={showIdScannerModal}
        onClose={() => setShowIdScannerModal(false)}
        onVerifySuccess={handleIdVerifySuccess}
      />

      {/* Supabase & PostgreSQL Schema Hub Modal */}
      <DbSchemaModal
        isOpen={showDbSchemaModal}
        onClose={() => setShowDbSchemaModal(false)}
      />

      {/* Global Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-900/60 py-6 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            UniCommute • High-Concurrency Transit, Traffic Consensus & Attendance Verification Platform
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <button 
              onClick={() => setShowDbSchemaModal(true)} 
              className="hover:text-indigo-300 transition underline underline-offset-4"
            >
              Supabase SQL Migrations
            </button>
            <span>•</span>
            <span>Domain: @university.edu</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
