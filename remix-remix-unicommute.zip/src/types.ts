export type UserRole = 'student' | 'faculty' | 'driver';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  institutionalId: string; // e.g. STU-2026-8942
  department: string;
  verifiedIdCard: boolean;
  idCardData?: {
    barcodeId: string;
    validThrough: string;
    photoUrl?: string;
    verifiedAt: string;
  };
  avatar: string;
  phoneNumber?: string;
}

export interface BusStop {
  id: string;
  name: string;
  lat: number;
  lng: number;
  sequence: number;
  landmark: string;
}

export interface BusRoute {
  id: string;
  name: string;
  code: string;
  color: string;
  operatingHours: string;
  frequencyMin: number;
  stops: BusStop[];
  pathCoordinates: [number, number][];
}

export interface LiveBus {
  id: string;
  routeId: string;
  routeName: string;
  routeColor: string;
  busNumber: string;
  driverName: string;
  driverId: string;
  lat: number;
  lng: number;
  speedKmH: number;
  headingDeg: number;
  nextStopId: string;
  nextStopName: string;
  etaNextStopMin: number;
  capacity: number;
  occupancy: number; // current passengers
  lastPingUtc: string;
  isBroadcasting: boolean;
  status: 'ON_TIME' | 'DELAYED_TRAFFIC' | 'MAINTENANCE';
}

export type IncidentType = 'JAM' | 'ROADBLOCK' | 'PROTEST' | 'ACCIDENT' | 'WEATHER_FLOOD' | 'BUS_BREAKDOWN';

export interface TrafficReport {
  id: string;
  reporterId: string;
  reporterName: string;
  reporterRole: UserRole;
  reporterEmail: string;
  incidentType: IncidentType;
  description: string;
  lat: number;
  lng: number;
  locationName: string;
  timestampUtc: string;
  clusterId?: string;
}

export interface TrafficCluster {
  id: string;
  incidentType: IncidentType;
  lat: number;
  lng: number;
  locationName: string;
  radiusMeters: number;
  reportCount: number; // Needs >= 3 reports within 300m in 15min to verify
  requiredReports: number; // 3
  verified: boolean;
  reports: TrafficReport[];
  firstReportedAt: string;
  lastReportedAt: string;
  affectedRoutes: string[];
  detourSuggested?: string;
  severity: 'LOW' | 'MEDIUM' | 'CRITICAL';
}

export interface CarpoolRider {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userRole: UserRole;
  seatsBooked: number;
  farePaidINR: number;
  pickupLocation: string;
  bookedAt: string;
}

export interface CarpoolRide {
  id: string;
  driverId: string;
  driverName: string;
  driverEmail: string;
  driverRole: UserRole;
  driverRating: number;
  vehicleModel: string;
  vehiclePlate: string;
  origin: string;
  destination: string;
  departureTime: string;
  totalSeats: number;
  availableSeats: number;
  totalFuelCostINR: number; // e.g. ₹320
  perSeatCostINR: number; // Dynamically computed = totalFuelCostINR / (1 driver + riders count) or totalFuelCostINR / confirmed riders
  riders: CarpoolRider[];
  safetyPin: string;
  status: 'OPEN' | 'FULL' | 'IN_TRANSIT' | 'COMPLETED' | 'CANCELLED';
  notes?: string;
}

export interface DelayAttendanceClaim {
  id: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  studentInstitutionalId: string;
  courseCode: string;
  courseName: string;
  professorId: string;
  professorName: string;
  classStartTime: string;
  capturedTimestampUtc: string;
  capturedGps: {
    lat: number;
    lng: number;
    accuracyMeters: number;
  };
  locationAddress: string;
  recordedVideoUrl?: string; // in-app camera recording proof
  capturedPhotoBase64?: string; // watermarked photo
  estimatedDelayMin: number;
  excuseReason: string;
  trafficProximityScore: number; // 0 to 100% computed against verified traffic cluster
  nearestVerifiedHazard?: {
    clusterId: string;
    incidentType: IncidentType;
    distanceMeters: number;
    locationName: string;
  };
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  professorDecisionComment?: string;
  reviewedAt?: string;
}

export interface LectureCourse {
  code: string;
  name: string;
  professor: string;
  department: string;
  schedule: string;
  room: string;
}

export interface LiveStreamSession {
  id: string;
  courseCode: string;
  courseName: string;
  professorName: string;
  topicTitle: string;
  isLive: boolean;
  viewerCount: number;
  startedAt: string;
  durationMinutes: number;
  videoPlaybackUrl: string;
  liveTranscript: Array<{ time: string; speaker: string; text: string }>;
  aiSummaryNotes: string[];
  keyDefinitions: Array<{ term: string; definition: string }>;
}

export interface StudyResource {
  id: string;
  courseCode: string;
  courseName: string;
  title: string;
  type: 'PDF_NOTES' | 'AUDIO_PODCAST' | 'LECTURE_SLIDES' | 'SUMMARY_CHEAT_SHEET';
  authorName: string;
  authorRole: string;
  uploadDate: string;
  downloadsCount: number;
  upvotes: number;
  durationOrPages: string;
  description: string;
  contentMarkdown?: string;
}

export type ActiveFeatureView = 
  | 'HOME_PORTAL'
  | 'BUS_TRACKER'
  | 'TRAFFIC_CONSENSUS'
  | 'CARPOOL_INR'
  | 'ATTENDANCE_DELAY'
  | 'STUDY_STREAM'
  | 'ID_OCR_MODAL'
  | 'DB_SCHEMA_HUB';
