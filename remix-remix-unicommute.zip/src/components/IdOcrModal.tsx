import React, { useState } from 'react';
import { 
  QrCode, 
  ShieldCheck, 
  Camera, 
  CheckCircle2, 
  Sparkles, 
  RefreshCw, 
  GraduationCap, 
  UserCheck, 
  Lock,
  Building,
  Calendar
} from 'lucide-react';
import { UserProfile } from '../types';
import confetti from 'canvas-confetti';

interface IdOcrModalProps {
  currentUser: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onVerifySuccess: (idData: any) => void;
}

export const IdOcrModal: React.FC<IdOcrModalProps> = ({
  currentUser,
  isOpen,
  onClose,
  onVerifySuccess
}) => {
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scannedData, setScannedData] = useState<any>(null);
  const [scanProgress, setScanProgress] = useState<number>(0);

  if (!isOpen) return null;

  const handleStartScan = () => {
    setIsScanning(true);
    setScanProgress(0);

    const interval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsScanning(false);
          const result = {
            barcodeId: `UNI-${currentUser.role === 'student' ? 'STU' : currentUser.role === 'faculty' ? 'FAC' : 'DRV'}-${Math.floor(1000 + Math.random() * 9000)}-X`,
            validThrough: '2028-06-30',
            verifiedAt: new Date().toISOString(),
            institutionalDomain: '@university.edu',
            department: currentUser.department
          };
          setScannedData(result);
          onVerifySuccess(result);
          confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
          return 100;
        }
        return prev + 25;
      });
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Institutional ID Card OCR Scanner</h3>
              <p className="text-xs text-slate-400">Locked to @university.edu credentials</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 font-bold">✕</button>
        </div>

        {/* Scanner Viewport / Card Display */}
        <div className="relative aspect-[1.6/1] rounded-2xl overflow-hidden bg-gradient-to-br from-slate-950 to-indigo-950/80 border-2 border-indigo-500/40 p-5 flex flex-col justify-between shadow-inner">
          {/* Scanning Laser Beam animation */}
          {isScanning && (
            <div 
              className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee] animate-pulse z-20"
              style={{ top: `${scanProgress}%`, transition: 'top 0.3s ease-out' }}
            />
          )}

          {/* Institutional Header */}
          <div className="flex items-center justify-between z-10">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-black text-xs">
                U
              </div>
              <div>
                <div className="text-[11px] font-extrabold text-white tracking-wide uppercase">University Institute</div>
                <div className="text-[9px] text-indigo-300">Identity & Transit Credential</div>
              </div>
            </div>
            <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30">
              VERIFIED DOMAIN
            </span>
          </div>

          {/* Card Body */}
          <div className="flex items-center gap-4 z-10 my-2">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-14 h-14 rounded-xl object-cover ring-2 ring-indigo-500/50"
              referrerPolicy="no-referrer"
            />
            <div className="space-y-0.5">
              <div className="text-sm font-bold text-white leading-tight">{currentUser.name}</div>
              <div className="text-[11px] font-mono text-cyan-300 font-semibold">{currentUser.institutionalId}</div>
              <div className="text-[10px] text-slate-400">{currentUser.department}</div>
              <div className="text-[10px] text-indigo-300 font-mono">{currentUser.email}</div>
            </div>
          </div>

          {/* Card Barcode Footer */}
          <div className="flex items-center justify-between border-t border-slate-800/80 pt-2 z-10 text-[10px] font-mono text-slate-400">
            <div>VALID THRU: 2028-06-30</div>
            <div className="tracking-widest text-slate-300">||| |||| || ||||| |||</div>
          </div>
        </div>

        {/* OCR Scanning Progress */}
        {isScanning && (
          <div className="space-y-2 text-xs">
            <div className="flex justify-between text-slate-300">
              <span className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                <Sparkles className="w-3.5 h-3.5 animate-spin" />
                Optical Character Recognition in progress...
              </span>
              <span className="font-mono text-white font-bold">{scanProgress}%</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-indigo-500 via-cyan-400 to-emerald-400 h-full transition-all duration-300"
                style={{ width: `${scanProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Action Controls */}
        <div className="space-y-3 pt-2">
          {!isScanning ? (
            <button
              id="btn-trigger-ocr-scan"
              onClick={handleStartScan}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/25 transition"
            >
              <Camera className="w-4 h-4" />
              <span>Simulate Live Camera Card OCR Scan</span>
            </button>
          ) : (
            <div className="text-center text-xs text-slate-400">
              Hold device steady over physical campus badge...
            </div>
          )}

          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Digital ID tokens are cryptographically linked to your institutional email for zero-trust campus authentication.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
