import React from 'react';
import { 
  Bus, 
  Car, 
  Clock, 
  Radio, 
  ShieldAlert, 
  BookOpen, 
  Database, 
  QrCode, 
  ArrowRight, 
  CheckCircle2, 
  Users, 
  Sparkles,
  IndianRupee,
  Navigation,
  Camera,
  Layers,
  GraduationCap
} from 'lucide-react';
import { ActiveFeatureView, UserProfile, LiveBus, TrafficCluster, CarpoolRide, DelayAttendanceClaim } from '../types';

interface HomePortalProps {
  onSelectFeature: (view: ActiveFeatureView) => void;
  currentUser: UserProfile;
  liveBuses: LiveBus[];
  trafficClusters: TrafficCluster[];
  carpools: CarpoolRide[];
  attendanceClaims: DelayAttendanceClaim[];
}

export const HomePortal: React.FC<HomePortalProps> = ({
  onSelectFeature,
  currentUser,
  liveBuses,
  trafficClusters,
  carpools,
  attendanceClaims
}) => {
  const verifiedHazardsCount = trafficClusters.filter(c => c.verified).length;
  const pendingClaimsCount = attendanceClaims.filter(c => c.status === 'PENDING').length;
  const availableSeatsCount = carpools.reduce((sum, r) => sum + r.availableSeats, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
      {/* Hero Welcome Section */}
      <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/80 border border-slate-800 p-6 sm:p-10 shadow-2xl overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Institutional Domain Locked: @university.edu</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white">
            University Commute & <span className="bg-gradient-to-r from-indigo-400 via-cyan-300 to-emerald-400 bg-clip-text text-transparent">Attendance Portal</span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Welcome back, <strong className="text-white font-semibold">{currentUser.name}</strong> ({currentUser.role.toUpperCase()} • {currentUser.department}). Select a core portal feature below to navigate transit maps, report traffic consensus, share carpool rides in ₹ INR, or verify commute delays with in-app camera locks.
          </p>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3">
            <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60">
              <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                <Bus className="w-3.5 h-3.5 text-blue-400" />
                Active Buses
              </div>
              <div className="text-lg font-bold text-white mt-1">
                {liveBuses.filter(b => b.isBroadcasting).length} <span className="text-xs font-normal text-emerald-400">Live</span>
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60">
              <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                Verified Hazards
              </div>
              <div className="text-lg font-bold text-white mt-1">
                {verifiedHazardsCount} <span className="text-xs font-normal text-amber-400">Consensus</span>
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60">
              <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                <IndianRupee className="w-3.5 h-3.5 text-emerald-400" />
                Open Carpool Seats
              </div>
              <div className="text-lg font-bold text-white mt-1">
                {availableSeatsCount} <span className="text-xs font-normal text-slate-300">Seats (₹)</span>
              </div>
            </div>

            <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60">
              <div className="text-[11px] font-medium text-slate-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-purple-400" />
                Pending Claims
              </div>
              <div className="text-lg font-bold text-white mt-1">
                {pendingClaimsCount} <span className="text-xs font-normal text-purple-400">Excuses</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Headings & Portals Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Core Campus Features
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Click on any heading below to open the dedicated feature view.
            </p>
          </div>
          <span className="text-xs font-medium text-indigo-400 bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20">
            Select Feature →
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {/* Card 1: Real-Time Bus Tracker & Navigation */}
          <div
            id="feature-card-bus-tracker"
            onClick={() => onSelectFeature('BUS_TRACKER')}
            className="group relative rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/60 p-6 shadow-lg hover:shadow-indigo-500/10 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                  <Navigation className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  3s GPS Telemetry
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition-colors">
                  1. Real-Time Bus Navigation & Fleet Radar
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Interactive Leaflet map with campus routes, 3-second live driver GPS telemetry broadcast, animated bus markers, and stop ETAs.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-slate-400">
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Driver Mode</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Live Stop ETA</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Occupancy Meter</span>
              </div>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-800/80 flex items-center justify-between text-indigo-400 group-hover:text-indigo-300 font-semibold text-xs">
              <span>Open Bus Tracker</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 2: Crowdsourced Traffic Consensus */}
          <div
            id="feature-card-traffic-consensus"
            onClick={() => onSelectFeature('TRAFFIC_CONSENSUS')}
            className="group relative rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/60 p-6 shadow-lg hover:shadow-amber-500/10 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  3+ Reports Edge Logic
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors">
                  2. Crowdsourced Traffic Consensus Engine
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Incident reporting for jams, roadblocks, accidents, & protests. Verified only when 3+ independent reports cluster within 300m in 15 mins.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-slate-400">
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">300m Clustering</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Hazard Detours</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Instant Alerting</span>
              </div>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-800/80 flex items-center justify-between text-amber-400 group-hover:text-amber-300 font-semibold text-xs">
              <span>View Traffic Consensus</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 3: Carpool & Equal Fare Split (₹ INR) */}
          <div
            id="feature-card-carpool"
            onClick={() => onSelectFeature('CARPOOL_INR')}
            className="group relative rounded-2xl bg-slate-900 border border-slate-800 hover:border-emerald-500/60 p-6 shadow-lg hover:shadow-emerald-500/10 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                  <Car className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Strictly in ₹ INR
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-emerald-300 transition-colors">
                  3. Carpooling & Dynamic Equal Fare Split (₹)
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Offer campus rides and book seats with dynamic equal fuel/toll splitting in Indian Rupees (₹). Recalculates live as riders join.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-slate-400">
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">₹ Equal Split Math</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Safety 4-digit PIN</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Seat Booking</span>
              </div>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-800/80 flex items-center justify-between text-emerald-400 group-hover:text-emerald-300 font-semibold text-xs">
              <span>Explore Carpools</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 4: Delay Attendance Verification */}
          <div
            id="feature-card-attendance"
            onClick={() => onSelectFeature('ATTENDANCE_DELAY')}
            className="group relative rounded-2xl bg-slate-900 border border-slate-800 hover:border-purple-500/60 p-6 shadow-lg hover:shadow-purple-500/10 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
                  <Camera className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  In-App Camera Lock
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
                  4. Delay Attendance Verification
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  In-app live camera recording (strictly no gallery uploads) with hardcoded UTC & GPS watermark, traffic correlation score, and Professor Review Portal.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-slate-400">
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Hardcoded GPS/UTC</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Proximity Scoring</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Faculty Approvals</span>
              </div>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-800/80 flex items-center justify-between text-purple-400 group-hover:text-purple-300 font-semibold text-xs">
              <span>Verify Delay Attendance</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 5: Commute Lecture Streaming & Study Hub */}
          <div
            id="feature-card-study-stream"
            onClick={() => onSelectFeature('STUDY_STREAM')}
            className="group relative rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-500/60 p-6 shadow-lg hover:shadow-cyan-500/10 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
                  <Radio className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Live Stream & Notes
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                  5. Commute Lecture Stream & Study Hub
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Live stream first-period morning lectures to delayed students in transit, synchronized live transcripts, AI summaries, and peer note repository.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-slate-400">
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Transit Live Stream</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">AI Key Points</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Podcast Mode</span>
              </div>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-800/80 flex items-center justify-between text-cyan-400 group-hover:text-cyan-300 font-semibold text-xs">
              <span>Open Study & Stream Hub</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Card 6: Student ID Card Verification */}
          <div
            id="feature-card-id-scanner"
            onClick={() => onSelectFeature('ID_OCR_MODAL')}
            className="group relative rounded-2xl bg-slate-900 border border-slate-800 hover:border-pink-500/60 p-6 shadow-lg hover:shadow-pink-500/10 transition-all duration-300 cursor-pointer flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-pink-400 group-hover:scale-110 transition-transform">
                  <QrCode className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-pink-500/20 text-pink-300 border border-pink-500/30">
                  Camera OCR
                </span>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white group-hover:text-pink-300 transition-colors">
                  6. Institutional Student ID OCR Scanner
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Institutional ID badge camera verification modal with real-time barcode extraction and institutional credentials validation.
                </p>
              </div>

              <div className="pt-2 flex flex-wrap gap-2 text-[11px] text-slate-400">
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Barcode Scanning</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Institutional Auth</span>
                <span className="bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700">Campus Pass</span>
              </div>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-800/80 flex items-center justify-between text-pink-400 group-hover:text-pink-300 font-semibold text-xs">
              <span>Scan & Verify ID</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>

        {/* Database & Schema Export Card */}
        <div 
          onClick={() => onSelectFeature('DB_SCHEMA_HUB')}
          className="mt-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800/80 to-slate-900 border border-slate-700/80 p-5 hover:border-slate-500 transition cursor-pointer flex flex-col sm:flex-row items-center justify-between gap-4"
        >
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-indigo-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                Supabase & PostgreSQL Production Schema Hub
                <span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full font-mono">
                  PostGIS + Realtime
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Inspect database tables, spatial indexes, 300m consensus trigger rules, and export SQL migrations.
              </p>
            </div>
          </div>
          <button className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-600 transition shrink-0">
            View SQL Migrations →
          </button>
        </div>
      </div>
    </div>
  );
};
