import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, 
  Video, 
  StopCircle, 
  Play, 
  ShieldCheck, 
  ShieldAlert, 
  Clock, 
  MapPin, 
  UserCheck, 
  XCircle, 
  CheckCircle2, 
  Sparkles, 
  Compass, 
  Lock, 
  AlertTriangle,
  FileCheck,
  RefreshCw
} from 'lucide-react';
import { DelayAttendanceClaim, TrafficCluster, UserProfile, UserRole } from '../types';
import { formatUtcDateTime, formatUtcTime } from '../utils/geo';
import { INITIAL_COURSES } from '../data/mockData';
import confetti from 'canvas-confetti';

interface AttendanceVerificationViewProps {
  claims: DelayAttendanceClaim[];
  trafficClusters: TrafficCluster[];
  currentUser: UserProfile;
  onSubmitClaim: (claim: Partial<DelayAttendanceClaim>) => void;
  onReviewClaim: (claimId: string, decision: 'APPROVE' | 'REJECT', comment?: string) => void;
}

export const AttendanceVerificationView: React.FC<AttendanceVerificationViewProps> = ({
  claims,
  trafficClusters,
  currentUser,
  onSubmitClaim,
  onReviewClaim
}) => {
  const [activeTab, setActiveTab] = useState<'SUBMIT' | 'PROFESSOR_PORTAL'>('SUBMIT');

  // In-App Camera State
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordedChunks, setRecordedChunks] = useState<Blob[]>([]);
  const [recordedVideoBlobUrl, setRecordedVideoBlobUrl] = useState<string | null>(null);
  const [capturedPhotoUrl, setCapturedPhotoUrl] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Live Watermark Metadata (UTC + GPS)
  const [liveUtcTimestamp, setLiveUtcTimestamp] = useState<string>(new Date().toISOString());
  const [liveGpsCoords, setLiveGpsCoords] = useState<{ lat: number; lng: number; accuracy: number }>({
    lat: 12.9774,
    lng: 77.5877,
    accuracy: 4.5
  });

  // Form Fields
  const [selectedCourseCode, setSelectedCourseCode] = useState<string>(INITIAL_COURSES[0].code);
  const [estimatedDelayMin, setEstimatedDelayMin] = useState<number>(35);
  const [excuseReason, setExcuseReason] = useState<string>('Route 1 bus blocked behind multi-vehicle accident on flyover ramp.');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Professor Review Modal State
  const [reviewingClaim, setReviewingClaim] = useState<DelayAttendanceClaim | null>(null);
  const [professorComment, setProfessorComment] = useState<string>('');

  // Clock ticker for live watermark
  useEffect(() => {
    const timer = setInterval(() => {
      setLiveUtcTimestamp(new Date().toISOString());
    }, 1000);

    // Try reading device GPS
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLiveGpsCoords({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: Math.round(pos.coords.accuracy)
          });
        },
        () => {
          // Default to simulated campus corridor coordinates
          setLiveGpsCoords({ lat: 12.9774, lng: 77.5877, accuracy: 4.8 });
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    }

    return () => clearInterval(timer);
  }, []);

  // In-App Camera Handlers
  const startCamera = async () => {
    try {
      setCameraError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsCameraActive(true);
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      setCameraError('Camera access unavailable or restricted in browser environment. Activating simulated in-app optical video lock.');
      setIsCameraActive(true);
    }
  };

  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(t => t.stop());
      mediaStreamRef.current = null;
    }
    setIsCameraActive(false);
    setIsRecording(false);
  };

  const startRecording = () => {
    setRecordedChunks([]);
    setRecordedVideoBlobUrl(null);

    if (mediaStreamRef.current && typeof MediaRecorder !== 'undefined') {
      try {
        const recorder = new MediaRecorder(mediaStreamRef.current);
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) {
            setRecordedChunks(prev => [...prev, e.data]);
          }
        };
        recorder.onstop = () => {
          const blob = new Blob(recordedChunks, { type: 'video/webm' });
          const url = URL.createObjectURL(blob);
          setRecordedVideoBlobUrl(url);
        };
        recorder.start();
        mediaRecorderRef.current = recorder;
        setIsRecording(true);
      } catch {
        simulateRecording();
      }
    } else {
      simulateRecording();
    }
  };

  const simulateRecording = () => {
    setIsRecording(true);
    setTimeout(() => {
      setIsRecording(false);
      setRecordedVideoBlobUrl('blob:simulated-in-app-watermarked-video');
      setCapturedPhotoUrl('https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&auto=format&fit=crop&q=80');
    }, 4000);
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    } else {
      setIsRecording(false);
      setRecordedVideoBlobUrl('blob:simulated-in-app-watermarked-video');
      setCapturedPhotoUrl('https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&auto=format&fit=crop&q=80');
    }
  };

  const captureWatermarkedSnapshot = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        // Draw hardcoded UTC & GPS watermark on image directly
        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.fillRect(10, canvas.height - 70, canvas.width - 20, 60);
        ctx.fillStyle = '#10b981';
        ctx.font = 'bold 16px monospace';
        ctx.fillText(`UTC: ${new Date().toISOString()}`, 20, canvas.height - 44);
        ctx.fillStyle = '#ffffff';
        ctx.font = '14px monospace';
        ctx.fillText(`GPS: ${liveGpsCoords.lat.toFixed(5)}N, ${liveGpsCoords.lng.toFixed(5)}E (Acc: ±${liveGpsCoords.accuracy}m)`, 20, canvas.height - 20);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setCapturedPhotoUrl(dataUrl);
        setRecordedVideoBlobUrl('blob:captured-watermarked-frame');
      }
    } else {
      setCapturedPhotoUrl('https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&auto=format&fit=crop&q=80');
      setRecordedVideoBlobUrl('blob:captured-watermarked-frame');
    }
  };

  const handleClaimSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const course = INITIAL_COURSES.find(c => c.code === selectedCourseCode) || INITIAL_COURSES[0];

    setIsSubmitting(true);
    onSubmitClaim({
      studentId: currentUser.id,
      studentName: currentUser.name,
      studentEmail: currentUser.email,
      studentInstitutionalId: currentUser.institutionalId,
      courseCode: course.code,
      courseName: course.name,
      professorName: course.professor,
      classStartTime: course.schedule.split(' ')[1] || '09:00 AM',
      capturedTimestampUtc: liveUtcTimestamp,
      capturedGps: {
        lat: liveGpsCoords.lat,
        lng: liveGpsCoords.lng,
        accuracyMeters: liveGpsCoords.accuracy
      },
      locationAddress: 'Residency Road Corridor Transit Stop',
      recordedVideoUrl: recordedVideoBlobUrl || 'blob:watermarked-camera-stream',
      capturedPhotoBase64: capturedPhotoUrl || 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&auto=format&fit=crop&q=80',
      estimatedDelayMin: Number(estimatedDelayMin),
      excuseReason
    });

    confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
    setIsSubmitting(false);
    stopCamera();
  };

  const handleProfessorDecision = (decision: 'APPROVE' | 'REJECT') => {
    if (!reviewingClaim) return;
    onReviewClaim(reviewingClaim.id, decision, professorComment);
    if (decision === 'APPROVE') {
      confetti({ particleCount: 80, spread: 80, origin: { y: 0.5 } });
    }
    setReviewingClaim(null);
    setProfessorComment('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400">
              <Camera className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              In-App Delay Attendance Verification
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            In-App Camera Lock (strictly live capture, no gallery uploads) with hardcoded UTC & GPS watermarks + Traffic Proximity Scoring.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center bg-slate-800/90 rounded-xl p-1 border border-slate-700 text-xs">
          <button
            onClick={() => setActiveTab('SUBMIT')}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
              activeTab === 'SUBMIT'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Student Submission</span>
          </button>

          <button
            onClick={() => setActiveTab('PROFESSOR_PORTAL')}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
              activeTab === 'PROFESSOR_PORTAL'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Professor Review Portal ({claims.filter(c => c.status === 'PENDING').length})</span>
          </button>
        </div>
      </div>

      {activeTab === 'SUBMIT' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: In-App Camera Lock Viewport */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                  <span className="text-sm font-bold text-white flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-purple-400" />
                    In-App Optical Camera Lock
                  </span>
                </div>
                <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  No Gallery Uploads Allowed
                </span>
              </div>

              {/* Viewport Frame */}
              <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-950 border-2 border-slate-800 flex items-center justify-center">
                {isCameraActive ? (
                  <>
                    <video
                      ref={videoRef}
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />

                    {/* Hardcoded Real-Time HUD Watermark Overlay */}
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-4 text-xs font-mono space-y-1">
                      <div className="flex items-center justify-between text-emerald-400">
                        <span className="font-bold flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" /> UTC: {liveUtcTimestamp}
                        </span>
                        <span className="bg-emerald-500/20 text-emerald-300 text-[10px] px-2 py-0.5 rounded border border-emerald-500/30">
                          TAMPER-PROOF METADATA
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-slate-300 text-[11px]">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-red-400" /> 
                          GPS: {liveGpsCoords.lat.toFixed(5)}N, {liveGpsCoords.lng.toFixed(5)}E (±{liveGpsCoords.accuracy}m)
                        </span>
                        <span className="text-indigo-300">{currentUser.institutionalId}</span>
                      </div>
                    </div>

                    {/* Recording Red Dot Indicator */}
                    {isRecording && (
                      <div className="absolute top-4 left-4 flex items-center gap-2 bg-rose-600/90 text-white text-xs px-3 py-1 rounded-full font-bold animate-pulse">
                        <span className="w-2 h-2 rounded-full bg-white" />
                        <span>LIVE RECORDING (00:04)</span>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center p-8 space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 mx-auto">
                      <Camera className="w-7 h-7" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white">Direct Camera Access Required</div>
                      <p className="text-xs text-slate-400 max-w-sm mt-1">
                        To maintain academic integrity, claims must be recorded directly on-device with locked GPS and UTC timestamps.
                      </p>
                    </div>
                    <button
                      id="btn-start-camera-lock"
                      onClick={startCamera}
                      className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/20 transition"
                    >
                      Initialize In-App Camera
                    </button>
                  </div>
                )}
              </div>

              {/* Camera Action Buttons */}
              {isCameraActive && (
                <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                  {!isRecording ? (
                    <>
                      <button
                        onClick={startRecording}
                        className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-600/20"
                      >
                        <Video className="w-4 h-4" />
                        <span>Record 5s Video Proof</span>
                      </button>

                      <button
                        onClick={captureWatermarkedSnapshot}
                        className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-2"
                      >
                        <Camera className="w-4 h-4" />
                        <span>Capture Watermarked Frame</span>
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={stopRecording}
                      className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-2 border border-slate-600"
                    >
                      <StopCircle className="w-4 h-4 text-rose-400" />
                      <span>Stop Recording</span>
                    </button>
                  )}

                  <button
                    onClick={stopCamera}
                    className="px-3 py-2 rounded-xl bg-slate-800 text-slate-400 hover:text-slate-200 text-xs"
                  >
                    Close Camera
                  </button>
                </div>
              )}

              {/* Proof Verified Banner */}
              {(recordedVideoBlobUrl || capturedPhotoUrl) && (
                <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-xl p-3 text-xs text-emerald-300 flex items-center justify-between">
                  <span className="flex items-center gap-2 font-semibold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Proof Captured & Tamper-Proof Watermark Embedded!
                  </span>
                  <span className="text-[10px] font-mono bg-emerald-500/20 px-2 py-0.5 rounded">
                    Ready to submit
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Claim Submission Details & Traffic Correlation */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
              <div>
                <h3 className="font-bold text-white text-base">Class & Commute Delay Details</h3>
                <p className="text-xs text-slate-400">Fill in your lecture info for professor verification.</p>
              </div>

              <form onSubmit={handleClaimSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Select Missed / Delayed Course</label>
                  <select
                    value={selectedCourseCode}
                    onChange={(e) => setSelectedCourseCode(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-purple-500"
                  >
                    {INITIAL_COURSES.map(course => (
                      <option key={course.code} value={course.code}>
                        {course.code} • {course.name} ({course.professor})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Estimated Delay Duration</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="5"
                      max="120"
                      value={estimatedDelayMin}
                      onChange={(e) => setEstimatedDelayMin(Number(e.target.value))}
                      className="w-24 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
                      required
                    />
                    <span className="text-slate-400">minutes late to class</span>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Transit Delay Justification</label>
                  <textarea
                    rows={3}
                    value={excuseReason}
                    onChange={(e) => setExcuseReason(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                    placeholder="Describe specific bus delay or hazard location..."
                    required
                  />
                </div>

                {/* Live Traffic Correlation Score Preview */}
                <div className="bg-slate-950/70 rounded-2xl p-4 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                      Traffic Proximity Correlation Score
                    </span>
                    <span className="font-bold text-sm text-emerald-400 font-mono">98% Match</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div className="bg-gradient-to-r from-cyan-400 to-emerald-400 h-full rounded-full w-[98%]" />
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Your GPS coordinates correlate within 38m of <strong>Consensus Verified Hazard on Residency Road (Route 1)</strong>.
                  </p>
                </div>

                <div className="pt-2">
                  <button
                    id="btn-submit-delay-claim"
                    type="submit"
                    disabled={isSubmitting || (!recordedVideoBlobUrl && !capturedPhotoUrl)}
                    className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition ${
                      (!recordedVideoBlobUrl && !capturedPhotoUrl)
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-600/20'
                    }`}
                  >
                    <FileCheck className="w-4 h-4" />
                    <span>Submit Excused Attendance Claim</span>
                  </button>
                  {(!recordedVideoBlobUrl && !capturedPhotoUrl) && (
                    <p className="text-[10px] text-amber-400 text-center mt-1.5">
                      * Please record video proof with in-app camera above before submitting.
                    </p>
                  )}
                </div>
              </form>
            </div>
          </div>
        </div>
      ) : (
        /* Professor Portal View: Review Attendance Claims */
        <div className="space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-indigo-400" />
                <span>Instructor Attendance Review Queue</span>
              </h2>
              <p className="text-xs text-slate-400">
                Inspect in-app camera proofs, verify GPS & UTC watermarks, and review automated traffic consensus proximity scores.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {claims.map(claim => {
              const isPending = claim.status === 'PENDING';
              const isApproved = claim.status === 'APPROVED';

              return (
                <div
                  key={claim.id}
                  className={`bg-slate-900 border rounded-2xl p-5 space-y-4 shadow-xl transition ${
                    isApproved ? 'border-emerald-500/50' : isPending ? 'border-purple-500/60' : 'border-rose-500/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-xs font-bold text-white">{claim.studentName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{claim.studentInstitutionalId} • {claim.courseCode}</div>
                    </div>

                    <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${
                      isApproved 
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
                        : isPending 
                        ? 'bg-purple-500/20 text-purple-300 border-purple-500/40 animate-pulse'
                        : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    }`}>
                      {claim.status}
                    </span>
                  </div>

                  {/* Optical Proof Image / Video Card */}
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                    <img
                      src={claim.capturedPhotoBase64 || 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=600&auto=format&fit=crop&q=80'}
                      alt="Delay Proof"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-x-0 bottom-0 bg-slate-950/85 p-2.5 text-[10px] font-mono text-slate-300 space-y-0.5">
                      <div className="text-emerald-400 flex items-center justify-between font-bold">
                        <span>UTC: {formatUtcDateTime(claim.capturedTimestampUtc)}</span>
                        <span className="text-cyan-400">Match: {claim.trafficProximityScore}%</span>
                      </div>
                      <div className="truncate">GPS: {claim.capturedGps.lat.toFixed(4)}, {claim.capturedGps.lng.toFixed(4)} ({claim.locationAddress})</div>
                    </div>
                  </div>

                  <div className="space-y-1 text-xs">
                    <div className="text-slate-300 font-medium">"{claim.excuseReason}"</div>
                    <div className="text-[11px] text-slate-400">
                      Estimated Delay: <strong>{claim.estimatedDelayMin} min</strong> • Class: {claim.courseName}
                    </div>
                  </div>

                  {/* Review / Decision Buttons */}
                  {isPending ? (
                    <div className="pt-2 flex items-center gap-2">
                      <button
                        onClick={() => {
                          setReviewingClaim(claim);
                          setProfessorComment('Verified with Route 1 consensus traffic incident. Excused attendance granted.');
                        }}
                        className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Approve Excuse</span>
                      </button>

                      <button
                        onClick={() => {
                          setReviewingClaim(claim);
                          setProfessorComment('Insufficient traffic proximity justification.');
                        }}
                        className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-rose-900/60 text-slate-300 hover:text-rose-200 text-xs font-semibold border border-slate-700"
                      >
                        Reject
                      </button>
                    </div>
                  ) : (
                    <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400">
                      <strong>Instructor Feedback:</strong> {claim.professorDecisionComment}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Professor Decision Confirmation Modal */}
      {reviewingClaim && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Review Attendance Excuse</h3>
              <button onClick={() => setReviewingClaim(null)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-xs space-y-1">
              <div className="font-semibold text-white">{reviewingClaim.studentName} ({reviewingClaim.studentInstitutionalId})</div>
              <div className="text-slate-400">{reviewingClaim.courseCode} • {reviewingClaim.courseName}</div>
              <div className="text-emerald-400 font-mono">Traffic Proximity Score: {reviewingClaim.trafficProximityScore}%</div>
            </div>

            <div>
              <label className="block text-slate-300 text-xs font-medium mb-1">Official Instructor Comment</label>
              <textarea
                rows={3}
                value={professorComment}
                onChange={(e) => setProfessorComment(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => handleProfessorDecision('REJECT')}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
              >
                Reject Claim
              </button>
              <button
                onClick={() => handleProfessorDecision('APPROVE')}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/20"
              >
                Approve & Excuse Attendance
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
