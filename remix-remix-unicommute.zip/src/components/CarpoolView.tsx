import React, { useState } from 'react';
import { 
  Car, 
  Plus, 
  IndianRupee, 
  Users, 
  Clock, 
  MapPin, 
  ShieldCheck, 
  Sparkles, 
  Key, 
  CheckCircle2, 
  Phone, 
  AlertCircle,
  Calendar
} from 'lucide-react';
import { CarpoolRide, UserProfile } from '../types';
import { formatINR } from '../utils/geo';
import confetti from 'canvas-confetti';

interface CarpoolViewProps {
  rides: CarpoolRide[];
  currentUser: UserProfile;
  onCreateRide: (rideData: Partial<CarpoolRide>) => void;
  onBookRide: (rideId: string, seats: number, pickup: string) => void;
}

export const CarpoolView: React.FC<CarpoolViewProps> = ({
  rides,
  currentUser,
  onCreateRide,
  onBookRide
}) => {
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [selectedRideForBooking, setSelectedRideForBooking] = useState<CarpoolRide | null>(null);

  // Form State for creating a new ride
  const [origin, setOrigin] = useState<string>('Koramangala 5th Block');
  const [destination, setDestination] = useState<string>('Engineering & Computing Quad Gate 2');
  const [departureTime, setDepartureTime] = useState<string>('08:15 AM');
  const [vehicleModel, setVehicleModel] = useState<string>('Honda City (White) / EV');
  const [vehiclePlate, setVehiclePlate] = useState<string>('KA-01-EQ-5590');
  const [totalSeats, setTotalSeats] = useState<number>(3);
  const [totalFuelCostINR, setTotalFuelCostINR] = useState<number>(360); // In Indian Rupees
  const [notes, setNotes] = useState<string>('Quiet study-friendly ride, AC on, non-smoking.');

  // Booking modal form
  const [bookingSeatsCount, setBookingSeatsCount] = useState<number>(1);
  const [bookingPickupLocation, setBookingPickupLocation] = useState<string>('');

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateRide({
      driverId: currentUser.id,
      driverName: currentUser.name,
      driverEmail: currentUser.email,
      driverRole: currentUser.role,
      origin,
      destination,
      departureTime,
      vehicleModel,
      vehiclePlate,
      totalSeats: Number(totalSeats),
      totalFuelCostINR: Number(totalFuelCostINR),
      notes
    });

    confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
    setShowCreateModal(false);
  };

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRideForBooking) return;

    onBookRide(selectedRideForBooking.id, bookingSeatsCount, bookingPickupLocation || selectedRideForBooking.origin);
    confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
    setSelectedRideForBooking(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <IndianRupee className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Campus Carpool & Dynamic Equal Fare Split
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Strictly in <strong>Indian Rupees (₹ INR)</strong> • Dynamic equal cost calculation among confirmed passengers
          </p>
        </div>

        <button
          id="btn-open-create-carpool-modal"
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Offer a Campus Ride (₹)</span>
        </button>
      </div>

      {/* Dynamic Equal Split Formula Explainer */}
      <div className="rounded-2xl bg-gradient-to-r from-emerald-950/50 via-slate-900 to-slate-900 border border-emerald-500/30 p-5">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Zero-Profit Fair Share Algorithm</span>
            </div>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              In accordance with university non-commercial ride regulations, drivers set the actual total fuel and toll expense in Indian Rupees (<strong className="text-emerald-400">₹ INR</strong>). When riders join, the system divides the total cost equally among all occupants. As more seats fill, everyone's share dynamically drops!
            </p>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-1">
            <div className="text-[11px] text-slate-400 font-semibold">Equal Split Example (₹360 fuel):</div>
            <div className="font-mono text-emerald-400 text-xs">
              1 Rider: ₹180 each • 2 Riders: ₹120 each • 3 Riders: ₹90 each
            </div>
          </div>
        </div>
      </div>

      {/* Carpools List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Car className="w-5 h-5 text-emerald-400" />
            <span>Available Campus Rides ({rides.length})</span>
          </h2>
          <span className="text-xs text-slate-400">Locked to verified institutional commuters</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {rides.map(ride => {
            const isFull = ride.availableSeats <= 0;
            const currentRidersCount = ride.riders.length;

            return (
              <div
                key={ride.id}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 space-y-4 shadow-lg transition-all flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Driver Header */}
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 font-bold text-sm text-white">
                        <span>{ride.driverName}</span>
                        <span className="text-[10px] uppercase px-2 py-0.5 rounded bg-slate-800 text-indigo-300 font-semibold">
                          {ride.driverRole}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">{ride.vehicleModel} • <span className="font-mono text-slate-300">{ride.vehiclePlate}</span></div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-lg font-extrabold text-emerald-400 font-mono">
                        {formatINR(ride.perSeatCostINR)}
                      </div>
                      <div className="text-[10px] text-slate-400">per passenger</div>
                    </div>
                  </div>

                  {/* Route & Time */}
                  <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 space-y-2 text-xs">
                    <div className="flex items-start gap-2">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-[10px] text-slate-500 uppercase font-semibold">Origin Pickup</div>
                        <div className="text-slate-200 font-medium">{ride.origin}</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                      <div>
                        <div className="text-[10px] text-slate-500 uppercase font-semibold">Campus Drop</div>
                        <div className="text-slate-200 font-medium">{ride.destination}</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        Leaves at <strong className="text-white">{ride.departureTime}</strong>
                      </span>
                      <span className="text-emerald-300 font-semibold font-mono">
                        Total Fuel: {formatINR(ride.totalFuelCostINR)}
                      </span>
                    </div>
                  </div>

                  {/* Seat Availability & Confirmed Roster */}
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Users className="w-3.5 h-3.5 text-slate-400" />
                        <span>Seats Available: <strong>{ride.availableSeats} of {ride.totalSeats}</strong></span>
                      </span>
                      <span className="font-mono text-[10px] text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                        PIN: {ride.safetyPin}
                      </span>
                    </div>

                    {/* Riders List */}
                    {ride.riders.length > 0 && (
                      <div className="bg-slate-950/40 rounded-lg p-2 text-[11px] text-slate-300 border border-slate-800/50 space-y-1">
                        <div className="text-[10px] text-slate-500 font-semibold">Confirmed Passengers:</div>
                        {ride.riders.map((r, i) => (
                          <div key={r.id || i} className="flex justify-between items-center text-slate-300">
                            <span>• {r.userName}</span>
                            <span className="text-emerald-400 font-mono font-semibold">{formatINR(r.farePaidINR)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Booking Button */}
                <div className="pt-2">
                  <button
                    disabled={isFull}
                    onClick={() => {
                      setSelectedRideForBooking(ride);
                      setBookingPickupLocation(ride.origin);
                    }}
                    className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                      isFull
                        ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20'
                    }`}
                  >
                    <IndianRupee className="w-3.5 h-3.5" />
                    <span>{isFull ? 'Ride Full' : `Book Seat • ${formatINR(ride.perSeatCostINR)}`}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal: Create Ride in INR */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <Car className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white">Offer Campus Carpool (₹ INR)</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Route Origin</label>
                  <input
                    type="text"
                    value={origin}
                    onChange={(e) => setOrigin(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                    placeholder="e.g. Koramangala 4th Block"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Campus Destination</label>
                  <input
                    type="text"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                    placeholder="e.g. Turing Hall Quad"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Departure Time</label>
                  <input
                    type="text"
                    value={departureTime}
                    onChange={(e) => setDepartureTime(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                    placeholder="08:15 AM"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Vehicle Plate / Model</label>
                  <input
                    type="text"
                    value={vehicleModel}
                    onChange={(e) => setVehicleModel(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                    placeholder="Honda City / EV"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Available Seats</label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    value={totalSeats}
                    onChange={(e) => setTotalSeats(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Total Trip Fuel/Toll (₹ INR)</label>
                  <input
                    type="number"
                    min="50"
                    max="2000"
                    value={totalFuelCostINR}
                    onChange={(e) => setTotalFuelCostINR(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500 font-mono font-bold text-emerald-400"
                    required
                  />
                </div>
              </div>

              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400">
                Estimated fare per rider with {totalSeats} passengers: <strong className="text-emerald-400 font-mono">{formatINR(totalFuelCostINR / (totalSeats + 1))}</strong> (Strictly calculated on actual confirmed riders).
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  id="btn-confirm-create-carpool"
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-lg shadow-emerald-600/20"
                >
                  Publish Ride (₹)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Book Ride in INR */}
      {selectedRideForBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  <IndianRupee className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white">Confirm Carpool Seat (₹ INR)</h3>
              </div>
              <button
                onClick={() => setSelectedRideForBooking(null)}
                className="text-slate-400 hover:text-white text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleBookSubmit} className="space-y-4 text-xs">
              <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 space-y-1">
                <div className="font-semibold text-slate-200">{selectedRideForBooking.driverName} ({selectedRideForBooking.vehicleModel})</div>
                <div className="text-slate-400">{selectedRideForBooking.origin} → {selectedRideForBooking.destination}</div>
                <div className="text-emerald-400 font-bold font-mono pt-1">Current Equal Split: {formatINR(selectedRideForBooking.perSeatCostINR)} / seat</div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Your Pickup Point / Landmark</label>
                <input
                  type="text"
                  value={bookingPickupLocation}
                  onChange={(e) => setBookingPickupLocation(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  placeholder="e.g. Sony World Bus Stop"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Number of Seats</label>
                <select
                  value={bookingSeatsCount}
                  onChange={(e) => setBookingSeatsCount(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                >
                  {Array.from({ length: selectedRideForBooking.availableSeats }, (_, i) => i + 1).map(num => (
                    <option key={num} value={num}>{num} Seat ({formatINR(selectedRideForBooking.perSeatCostINR * num)})</option>
                  ))}
                </select>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedRideForBooking(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  id="btn-confirm-book-seat"
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-lg shadow-emerald-600/20"
                >
                  Confirm Booking ({formatINR(selectedRideForBooking.perSeatCostINR * bookingSeatsCount)})
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
