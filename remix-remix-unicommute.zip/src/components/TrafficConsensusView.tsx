import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Plus, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Users, 
  ArrowRight, 
  Radio, 
  Compass, 
  Sparkles,
  Info,
  ShieldCheck
} from 'lucide-react';
import { TrafficCluster, TrafficReport, IncidentType, UserProfile } from '../types';
import { formatUtcTime, formatUtcDateTime } from '../utils/geo';

interface TrafficConsensusViewProps {
  clusters: TrafficCluster[];
  allReports: TrafficReport[];
  currentUser: UserProfile;
  onSubmitReport: (report: Partial<TrafficReport>) => void;
}

export const TrafficConsensusView: React.FC<TrafficConsensusViewProps> = ({
  clusters,
  allReports,
  currentUser,
  onSubmitReport
}) => {
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [selectedIncidentType, setSelectedIncidentType] = useState<IncidentType>('JAM');
  const [reportDescription, setReportDescription] = useState<string>('');
  const [reportLocationName, setReportLocationName] = useState<string>('Residency Road Flyover Descent');
  const [customLat, setCustomLat] = useState<number>(12.9775);
  const [customLng, setCustomLng] = useState<number>(77.5878);

  const verifiedClusters = clusters.filter(c => c.verified);
  const pendingClusters = clusters.filter(c => !c.verified);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportDescription.trim()) return;

    onSubmitReport({
      reporterId: currentUser.id,
      reporterName: currentUser.name,
      reporterRole: currentUser.role,
      reporterEmail: currentUser.email,
      incidentType: selectedIncidentType,
      description: reportDescription,
      locationName: reportLocationName,
      lat: customLat,
      lng: customLng,
      timestampUtc: new Date().toISOString()
    });

    setReportDescription('');
    setShowReportModal(false);
  };

  const getIncidentBadgeColor = (type: IncidentType) => {
    switch (type) {
      case 'JAM': return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'ROADBLOCK': return 'bg-rose-500/20 text-rose-300 border-rose-500/40';
      case 'ACCIDENT': return 'bg-red-500/20 text-red-300 border-red-500/40';
      case 'PROTEST': return 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      case 'WEATHER_FLOOD': return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      case 'BUS_BREAKDOWN': return 'bg-orange-500/20 text-orange-300 border-orange-500/40';
      default: return 'bg-slate-500/20 text-slate-300 border-slate-500/40';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Crowdsourced Traffic Consensus Engine
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Edge Consensus Logic: Verifies transit hazards when <strong>3+ independent reports</strong> cluster within <strong>300m in 15 mins</strong>.
          </p>
        </div>

        <button
          id="btn-open-report-incident-modal"
          onClick={() => setShowReportModal(true)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 transition shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Report Live Traffic Incident</span>
        </button>
      </div>

      {/* Edge Verification Logic Explainer Card */}
      <div className="rounded-2xl bg-gradient-to-r from-indigo-950/60 via-slate-900 to-slate-900 border border-indigo-500/30 p-5">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-indigo-300 font-bold text-sm">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>Edge Consensus Protocol Active</span>
            </div>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              To prevent false alarm spam, raw reports enter a <span className="text-amber-400 font-semibold">Pending</span> state. When 3 or more independent authenticated campus commuters submit corroborating reports within a 300-meter radius, the system instantly validates the cluster, activates university broadcast banners, and updates delay attendance scoring algorithms.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0 bg-slate-950/70 px-4 py-2.5 rounded-xl border border-slate-800">
            <div className="text-center">
              <div className="text-xs text-slate-400">Radius</div>
              <div className="text-sm font-bold text-white">300 Meters</div>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div className="text-center">
              <div className="text-xs text-slate-400">Window</div>
              <div className="text-sm font-bold text-white">15 Minutes</div>
            </div>
            <div className="h-6 w-px bg-slate-800" />
            <div className="text-center">
              <div className="text-xs text-slate-400">Quorum</div>
              <div className="text-sm font-bold text-emerald-400">≥ 3 Reports</div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of Verified & Pending Incidents */}
      <div className="space-y-6">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span>Consensus-Verified Hazard Clusters ({verifiedClusters.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Active alerts affecting university transit routes and auto-excusing correlated attendance claims.
          </p>
        </div>

        {verifiedClusters.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
            No active verified traffic blockages on campus routes. All transit corridors operating normally.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {verifiedClusters.map(cluster => (
              <div
                key={cluster.id}
                className="bg-slate-900 border-2 border-red-500/60 rounded-2xl p-5 space-y-4 shadow-xl shadow-red-500/5 relative overflow-hidden"
              >
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${getIncidentBadgeColor(cluster.incidentType)}`}>
                    {cluster.incidentType}
                  </span>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Consensus Verified ({cluster.reportCount} Reports)
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-red-400 shrink-0" />
                    <span>{cluster.locationName}</span>
                  </h3>
                  <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Active since {formatUtcTime(cluster.firstReportedAt)}</span>
                  </div>
                </div>

                {cluster.detourSuggested && (
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 text-xs text-amber-200">
                    <strong>Recommended Transit Detour:</strong> {cluster.detourSuggested}
                  </div>
                )}

                {/* Corroborating reports summary */}
                <div className="space-y-1.5 pt-1 border-t border-slate-800">
                  <div className="text-[11px] font-semibold text-slate-400">Corroborating Commuter Reports:</div>
                  {cluster.reports.map((rep, idx) => (
                    <div key={rep.id || idx} className="bg-slate-950/60 rounded-lg p-2 text-xs text-slate-300 border border-slate-800/80">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
                        <span className="font-semibold text-slate-200">{rep.reporterName} ({rep.reporterRole.toUpperCase()})</span>
                        <span>{formatUtcTime(rep.timestampUtc)}</span>
                      </div>
                      <p className="text-slate-300">{rep.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pending Unverified Reports */}
        <div className="pt-4">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-amber-400" />
            <span>Pending Incident Quorum ({pendingClusters.length})</span>
          </h2>
          <p className="text-xs text-slate-400">
            Awaiting 3+ corroborating reports within 300m to attain consensus status.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-4">
            {pendingClusters.map(cluster => (
              <div
                key={cluster.id}
                className="bg-slate-900 border border-amber-500/40 rounded-2xl p-5 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${getIncidentBadgeColor(cluster.incidentType)}`}>
                    {cluster.incidentType}
                  </span>
                  <div className="flex items-center gap-1.5 text-xs text-amber-400 font-semibold">
                    <span>Quorum Progress:</span>
                    <strong className="font-bold">{cluster.reportCount}/{cluster.requiredReports}</strong>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white">{cluster.locationName}</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    First reported at {formatUtcTime(cluster.firstReportedAt)}. Needs {cluster.requiredReports - cluster.reportCount} more commuter confirmation(s) within 300m.
                  </p>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div 
                    className="bg-amber-400 h-full rounded-full transition-all"
                    style={{ width: `${(cluster.reportCount / cluster.requiredReports) * 100}%` }}
                  />
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    onClick={() => {
                      setReportLocationName(cluster.locationName);
                      setSelectedIncidentType(cluster.incidentType);
                      setCustomLat(cluster.lat);
                      setCustomLng(cluster.lng);
                      setShowReportModal(true);
                    }}
                    className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1"
                  >
                    <span>Confirm this Hazard (+1 Vote)</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Incident Reporting Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-white">Report Transit Incident</h3>
              </div>
              <button
                onClick={() => setShowReportModal(false)}
                className="text-slate-400 hover:text-white text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1.5">
                  Hazard / Incident Category
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['JAM', 'ROADBLOCK', 'ACCIDENT', 'PROTEST', 'WEATHER_FLOOD', 'BUS_BREAKDOWN'] as IncidentType[]).map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setSelectedIncidentType(type)}
                      className={`p-2 rounded-xl font-bold text-[11px] border text-center transition ${
                        selectedIncidentType === type
                          ? 'bg-amber-500 text-slate-950 border-amber-400'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Location / Transit Landmark
                </label>
                <input
                  type="text"
                  value={reportLocationName}
                  onChange={(e) => setReportLocationName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-500"
                  placeholder="e.g. Residency Road Junction Flyover"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Live Delay Details & Ground Description
                </label>
                <textarea
                  rows={3}
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-white focus:outline-none focus:border-amber-500"
                  placeholder="Describe the standstill, blocked lanes, or estimated delay..."
                  required
                />
              </div>

              <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="flex items-center justify-between text-slate-300 font-semibold">
                  <span>Geotag Coordinates:</span>
                  <span className="font-mono text-amber-400">{customLat.toFixed(4)}, {customLng.toFixed(4)}</span>
                </div>
                <p>Auto-clustered within 300m radius of existing campus corridor incidents.</p>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  id="btn-submit-traffic-report"
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold shadow-lg shadow-amber-500/20"
                >
                  Submit Incident Report
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
