import React, { useState } from 'react';
import { Database, Copy, Check, Code, Layers, Sparkles, Shield, ArrowRight } from 'lucide-react';

interface DbSchemaModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DbSchemaModal: React.FC<DbSchemaModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const sqlSchema = `-- ==========================================================
-- UniCommute Supabase / PostgreSQL Production Migration Schema
-- Database tables, Real-time Subscriptions, & Edge Trigger Rules
-- ==========================================================

-- 1. Enable PostGIS & UUID extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- 2. Profiles Table (Restricted to @university.edu domains)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE CHECK (email LIKE '%@university.edu'),
  role TEXT NOT NULL CHECK (role IN ('student', 'faculty', 'driver')),
  institutional_id TEXT NOT NULL UNIQUE,
  department TEXT NOT NULL,
  verified_id_card BOOLEAN DEFAULT false,
  id_barcode TEXT,
  phone_number TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Bus Routes and Stops
CREATE TABLE IF NOT EXISTS public.bus_routes (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  color TEXT NOT NULL,
  operating_hours TEXT NOT NULL,
  frequency_min INTEGER NOT NULL DEFAULT 15,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.bus_stops (
  id TEXT PRIMARY KEY,
  route_id TEXT REFERENCES public.bus_routes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  location GEOGRAPHY(POINT, 4326) NOT NULL,
  sequence_num INTEGER NOT NULL,
  landmark TEXT
);

-- 4. Real-time Live Fleet Telemetry (Updated every 3 seconds)
CREATE TABLE IF NOT EXISTS public.live_buses (
  id TEXT PRIMARY KEY,
  route_id TEXT REFERENCES public.bus_routes(id),
  bus_number TEXT NOT NULL,
  driver_id UUID REFERENCES public.profiles(id),
  current_location GEOGRAPHY(POINT, 4326) NOT NULL,
  speed_kmh NUMERIC(5,2) DEFAULT 0,
  heading_deg NUMERIC(5,2) DEFAULT 0,
  next_stop_id TEXT REFERENCES public.bus_stops(id),
  eta_next_stop_min INTEGER DEFAULT 5,
  capacity INTEGER DEFAULT 50,
  occupancy INTEGER DEFAULT 0,
  status TEXT DEFAULT 'ON_TIME' CHECK (status IN ('ON_TIME', 'DELAYED_TRAFFIC', 'MAINTENANCE')),
  last_ping_utc TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Traffic Incidents & Consensus Clusters
-- Edge rule: Incident verified when 3+ reports exist within 300m within 15min
CREATE TABLE IF NOT EXISTS public.traffic_clusters (
  id TEXT PRIMARY KEY,
  incident_type TEXT NOT NULL CHECK (incident_type IN ('JAM', 'ROADBLOCK', 'PROTEST', 'ACCIDENT', 'WEATHER_FLOOD', 'BUS_BREAKDOWN')),
  location GEOGRAPHY(POINT, 4326) NOT NULL,
  location_name TEXT NOT NULL,
  radius_meters INTEGER DEFAULT 300,
  report_count INTEGER DEFAULT 1,
  required_reports INTEGER DEFAULT 3,
  verified BOOLEAN DEFAULT false,
  severity TEXT DEFAULT 'MEDIUM' CHECK (severity IN ('LOW', 'MEDIUM', 'CRITICAL')),
  detour_suggested TEXT,
  first_reported_at TIMESTAMPTZ DEFAULT NOW(),
  last_reported_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Carpools with Equal Fuel/Toll Split in Indian Rupees (₹ INR)
CREATE TABLE IF NOT EXISTS public.carpool_rides (
  id TEXT PRIMARY KEY,
  driver_id UUID REFERENCES public.profiles(id),
  origin TEXT NOT NULL,
  destination TEXT NOT NULL,
  departure_time TEXT NOT NULL,
  total_seats INTEGER NOT NULL CHECK (total_seats > 0),
  available_seats INTEGER NOT NULL,
  total_fuel_cost_inr NUMERIC(10,2) NOT NULL CHECK (total_fuel_cost_inr > 0),
  per_seat_cost_inr NUMERIC(10,2) NOT NULL,
  safety_pin TEXT NOT NULL,
  status TEXT DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'FULL', 'IN_TRANSIT', 'COMPLETED', 'CANCELLED')),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Delay Attendance Claims (In-App Camera Proof & GPS Watermark)
CREATE TABLE IF NOT EXISTS public.delay_attendance_claims (
  id TEXT PRIMARY KEY,
  student_id UUID REFERENCES public.profiles(id),
  course_code TEXT NOT NULL,
  course_name TEXT NOT NULL,
  professor_id UUID REFERENCES public.profiles(id),
  class_start_time TEXT NOT NULL,
  captured_timestamp_utc TIMESTAMPTZ NOT NULL,
  captured_location GEOGRAPHY(POINT, 4326) NOT NULL,
  location_address TEXT NOT NULL,
  recorded_video_url TEXT,
  captured_photo_url TEXT,
  estimated_delay_min INTEGER NOT NULL,
  excuse_reason TEXT NOT NULL,
  traffic_proximity_score NUMERIC(5,2) DEFAULT 0,
  status TEXT DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  professor_decision_comment TEXT,
  reviewed_at TIMESTAMPTZ
);

-- 8. Enable Realtime Publications
ALTER PUBLICATION supabase_realtime ADD TABLE public.live_buses;
ALTER PUBLICATION supabase_realtime ADD TABLE public.traffic_clusters;
ALTER PUBLICATION supabase_realtime ADD TABLE public.carpool_rides;
ALTER PUBLICATION supabase_realtime ADD TABLE public.delay_attendance_claims;
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(sqlSchema);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-3xl w-full shadow-2xl space-y-5 max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-indigo-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Supabase / PostgreSQL Migration Script</h3>
              <p className="text-xs text-slate-400">PostGIS Geography Types • Real-Time Publications • 300m Edge Triggers</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white font-bold p-1">✕</button>
        </div>

        <div className="flex-1 overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 flex flex-col">
          <div className="bg-slate-900/90 px-4 py-2 border-b border-slate-800 flex items-center justify-between text-xs">
            <span className="font-mono text-indigo-300">schema_migrations.sql</span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold border border-slate-700 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard' : 'Copy SQL Schema'}</span>
            </button>
          </div>
          <div className="p-4 overflow-y-auto font-mono text-[11px] text-slate-300 leading-relaxed">
            <pre>{sqlSchema}</pre>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
          <span>Target Platform: PostgreSQL 15+ / Supabase Database</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold"
          >
            Close Schema Viewer
          </button>
        </div>
      </div>
    </div>
  );
};
