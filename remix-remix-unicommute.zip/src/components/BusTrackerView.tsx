import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { 
  Bus, 
  Play, 
  Square, 
  Navigation, 
  Users, 
  Gauge, 
  MapPin, 
  Clock, 
  ShieldAlert, 
  Compass, 
  Radio, 
  Layers, 
  CheckCircle2, 
  RefreshCw,
  ArrowRight,
  Sparkles,
  Info
} from 'lucide-react';
import { BusRoute, LiveBus, TrafficCluster, UserProfile, UserRole } from '../types';
import { calculateBearing } from '../utils/geo';

interface BusTrackerViewProps {
  routes: BusRoute[];
  buses: LiveBus[];
  trafficClusters: TrafficCluster[];
  currentUser: UserProfile;
  onDriverPing: (busUpdate: Partial<LiveBus>) => void;
  onSelectTrafficIncident?: (clusterId: string) => void;
}

export const BusTrackerView: React.FC<BusTrackerViewProps> = ({
  routes,
  buses,
  trafficClusters,
  currentUser,
  onDriverPing,
  onSelectTrafficIncident
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const busMarkersRef = useRef<Record<string, L.Marker>>({});
  const hazardLayersRef = useRef<L.LayerGroup | null>(null);

  const [selectedRouteId, setSelectedRouteId] = useState<string>(routes[0]?.id || 'route-blue-01');
  const [selectedBusId, setSelectedBusId] = useState<string>(buses[0]?.id || 'bus-14');
  
  // Driver Telemetry Transmission State
  const [isDriverBroadcasting, setIsDriverBroadcasting] = useState<boolean>(false);
  const [driverSpeed, setDriverSpeed] = useState<number>(36);
  const [driverOccupancy, setDriverOccupancy] = useState<number>(38);
  const [driverNextStopIndex, setDriverNextStopIndex] = useState<number>(2);
  const [simulatedWaypointIdx, setSimulatedWaypointIdx] = useState<number>(0);

  const activeRoute = routes.find(r => r.id === selectedRouteId) || routes[0];
  const selectedBus = buses.find(b => b.id === selectedBusId) || buses[0];

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Create Leaflet Map centered at Tech Campus
      const map = L.map(mapContainerRef.current, {
        center: [12.9716, 77.5946],
        zoom: 14,
        zoomControl: false
      });

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      // CartoDB Dark Matter tiles for sleek modern dark mode
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://carto.com/">CARTO</a>, &copy; OpenStreetMap',
        maxZoom: 19,
      }).addTo(map);

      hazardLayersRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    return () => {
      // cleanup on unmount
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Draw Routes, Stops & Hazard Circles
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Draw route polylines
    routes.forEach(route => {
      const isSelected = route.id === selectedRouteId;
      const polyline = L.polyline(route.pathCoordinates, {
        color: route.color,
        weight: isSelected ? 6 : 3,
        opacity: isSelected ? 0.9 : 0.45,
        dashArray: isSelected ? undefined : '5, 8'
      }).addTo(map);

      polyline.bindPopup(`
        <div style="font-family: sans-serif;">
          <div style="font-weight: 700; color: ${route.color};">${route.name}</div>
          <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">Hours: ${route.operatingHours}</div>
          <div style="font-size: 11px; color: #94a3b8;">Frequency: Every ${route.frequencyMin} min</div>
        </div>
      `);

      // Draw Stops
      route.stops.forEach(stop => {
        const stopIcon = L.divIcon({
          className: 'custom-stop-icon',
          html: `
            <div style="
              width: 22px; 
              height: 22px; 
              background: #0f172a; 
              border: 2.5px solid ${route.color}; 
              border-radius: 50%; 
              display: flex; 
              align-items: center; 
              justify-content: center; 
              box-shadow: 0 2px 6px rgba(0,0,0,0.4);
            ">
              <span style="font-size: 9px; font-weight: 800; color: #f8fafc;">${stop.sequence}</span>
            </div>
          `,
          iconSize: [22, 22],
          iconAnchor: [11, 11]
        });

        const stopMarker = L.marker([stop.lat, stop.lng], { icon: stopIcon }).addTo(map);
        stopMarker.bindPopup(`
          <div style="font-family: sans-serif; min-width: 140px;">
            <div style="font-size: 10px; text-transform: uppercase; color: ${route.color}; font-weight: 700;">Stop #${stop.sequence}</div>
            <div style="font-weight: 700; color: #f8fafc; font-size: 13px;">${stop.name}</div>
            <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">📍 ${stop.landmark}</div>
            <div style="font-size: 11px; color: #38bdf8; font-weight: 600; margin-top: 4px;">⏱️ Next Bus ETA: ~${stop.sequence * 3} min</div>
          </div>
        `);
      });
    });

    // Render Traffic Hazard Circles & Warnings
    if (hazardLayersRef.current) {
      hazardLayersRef.current.clearLayers();
      trafficClusters.forEach(cluster => {
        const isVerified = cluster.verified;
        const color = isVerified ? '#ef4444' : '#f59e0b';
        
        const circle = L.circle([cluster.lat, cluster.lng], {
          radius: cluster.radiusMeters,
          color: color,
          fillColor: color,
          fillOpacity: isVerified ? 0.35 : 0.2,
          weight: 2,
          dashArray: isVerified ? undefined : '4, 4'
        });

        circle.bindPopup(`
          <div style="font-family: sans-serif; min-width: 180px;">
            <div style="display: flex; align-items: center; justify-content: space-between;">
              <span style="font-size: 10px; font-weight: 800; color: ${color}; text-transform: uppercase;">
                ${isVerified ? '⚠️ VERIFIED HAZARD' : '⏳ PENDING CONSENSUS'}
              </span>
              <span style="font-size: 10px; background: #334155; padding: 1px 6px; border-radius: 999px; color: #e2e8f0;">
                ${cluster.reportCount}/${cluster.requiredReports} reports
              </span>
            </div>
            <div style="font-weight: 700; color: #f8fafc; font-size: 13px; margin-top: 4px;">${cluster.locationName}</div>
            <div style="font-size: 11px; color: #cbd5e1; margin-top: 2px;">Type: <strong>${cluster.incidentType}</strong></div>
            ${cluster.detourSuggested ? `<div style="font-size: 10px; color: #fbbf24; margin-top: 4px; border-top: 1px solid #334155; padding-top: 3px;">↪ ${cluster.detourSuggested}</div>` : ''}
          </div>
        `);

        hazardLayersRef.current?.addLayer(circle);
      });
    }
  }, [routes, selectedRouteId, trafficClusters]);

  // Update Live Bus Markers on map
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    buses.forEach(bus => {
      const isSelected = bus.id === selectedBusId;
      const busColor = bus.routeColor || '#3b82f6';
      
      const customBusIcon = L.divIcon({
        className: 'custom-live-bus-marker',
        html: `
          <div style="
            width: 38px;
            height: 38px;
            background: #090d16;
            border: 2.5px solid ${isSelected ? '#ffffff' : busColor};
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.6);
            transform: rotate(${bus.headingDeg}deg);
            position: relative;
            transition: all 0.3s ease;
          ">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${busColor}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M8 6v6"/>
              <path d="M15 6v6"/>
              <path d="M2 12h19.6"/>
              <path d="M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4C2.9 6 1.9 6.8 1.6 7.8L.2 12.8c-.1.4-.2.8-.2 1.2 0 .4.1.8.2 1.2.3 1.1.8 2.8.8 2.8h3"/>
              <circle cx="7" cy="18" r="2"/>
              <circle cx="15" cy="18" r="2"/>
            </svg>
            ${bus.isBroadcasting ? `
              <span style="
                position: absolute;
                top: -4px;
                right: -4px;
                width: 8px;
                height: 8px;
                background: #10b981;
                border-radius: 50%;
                border: 1.5px solid #090d16;
              "></span>
            ` : ''}
          </div>
        `,
        iconSize: [38, 38],
        iconAnchor: [19, 19]
      });

      if (busMarkersRef.current[bus.id]) {
        busMarkersRef.current[bus.id].setLatLng([bus.lat, bus.lng]);
        busMarkersRef.current[bus.id].setIcon(customBusIcon);
      } else {
        const marker = L.marker([bus.lat, bus.lng], { icon: customBusIcon }).addTo(map);
        marker.bindPopup(`
          <div style="font-family: sans-serif; min-width: 160px;">
            <div style="display: flex; align-items: center; justify-content: space-between;">
              <span style="font-weight: 800; font-size: 13px; color: ${busColor};">${bus.busNumber}</span>
              <span style="font-size: 10px; background: #064e3b; color: #34d399; padding: 1px 6px; border-radius: 4px; font-weight: 700;">
                ${bus.speedKmH} km/h
              </span>
            </div>
            <div style="font-size: 11px; color: #f8fafc; font-weight: 600; margin-top: 3px;">Driver: ${bus.driverName}</div>
            <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">Next: <strong>${bus.nextStopName}</strong></div>
            <div style="font-size: 11px; color: #38bdf8; font-weight: 600; margin-top: 2px;">ETA: ~${bus.etaNextStopMin} min</div>
            <div style="margin-top: 5px; font-size: 10px; color: #cbd5e1;">
              Occupancy: ${bus.occupancy}/${bus.capacity} passengers (${Math.round((bus.occupancy/bus.capacity)*100)}%)
            </div>
          </div>
        `);
        busMarkersRef.current[bus.id] = marker;
      }
    });
  }, [buses, selectedBusId]);

  // Driver GPS Telemetry Transmission Simulation (3-second intervals)
  useEffect(() => {
    let interval: any = null;
    if (isDriverBroadcasting) {
      interval = setInterval(() => {
        // Step along route path coordinates
        const pathCoords = activeRoute.pathCoordinates;
        setSimulatedWaypointIdx(prev => {
          const nextIdx = (prev + 1) % pathCoords.length;
          const currentPoint = pathCoords[prev];
          const nextPoint = pathCoords[nextIdx];
          const bearing = calculateBearing(currentPoint[0], currentPoint[1], nextPoint[0], nextPoint[1]);

          const stopIndex = Math.min(Math.floor((nextIdx / pathCoords.length) * activeRoute.stops.length), activeRoute.stops.length - 1);
          const nextStop = activeRoute.stops[stopIndex] || activeRoute.stops[0];

          onDriverPing({
            id: selectedBus.id,
            lat: nextPoint[0],
            lng: nextPoint[1],
            speedKmH: driverSpeed + Math.floor(Math.random() * 5 - 2),
            headingDeg: bearing,
            nextStopId: nextStop.id,
            nextStopName: nextStop.name,
            etaNextStopMin: Math.max(1, Math.round((activeRoute.stops.length - stopIndex) * 2.5)),
            occupancy: Math.min(selectedBus.capacity, Math.max(10, driverOccupancy + Math.floor(Math.random() * 3 - 1))),
            isBroadcasting: true
          });

          return nextIdx;
        });
      }, 3000); // 3 seconds transmission requirement!
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isDriverBroadcasting, activeRoute, selectedBus, driverSpeed, driverOccupancy, onDriverPing]);

  const handleCenterBus = (bus: LiveBus) => {
    setSelectedBusId(bus.id);
    setSelectedRouteId(bus.routeId);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([bus.lat, bus.lng], 16, { duration: 1.2 });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Header & Mode Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400">
              <Bus className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Campus Fleet Radar & Navigation
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time GPS telemetry broadcast every 3s • Live arrival estimates • Animated transit routes
          </p>
        </div>

        {/* Quick Route Selector Filter */}
        <div className="flex flex-wrap items-center gap-2">
          {routes.map(r => (
            <button
              key={r.id}
              onClick={() => {
                setSelectedRouteId(r.id);
                const busOnRoute = buses.find(b => b.routeId === r.id);
                if (busOnRoute) setSelectedBusId(busOnRoute.id);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition flex items-center gap-1.5 ${
                selectedRouteId === r.id
                  ? 'bg-slate-800 text-white border-indigo-500 shadow-md'
                  : 'bg-slate-900/80 text-slate-400 border-slate-700 hover:text-slate-200'
              }`}
            >
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: r.color }} />
              <span>{r.code}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Map & Telemetry Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Interactive Leaflet Map */}
        <div className="lg:col-span-2 space-y-4">
          <div className="relative rounded-2xl overflow-hidden border border-slate-800 bg-slate-950 shadow-xl h-[480px] sm:h-[540px]">
            {/* Map Div */}
            <div ref={mapContainerRef} className="w-full h-full z-10" />

            {/* Map Overlay Floating HUD */}
            <div className="absolute top-3 left-3 z-20 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 shadow-lg max-w-xs space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                  Fleet Telemetry Active
                </span>
                <span className="text-[10px] text-slate-400 font-mono">3s Sync</span>
              </div>
              <div className="text-[11px] text-slate-300">
                Tracking <strong>{buses.length} campus buses</strong> across {routes.length} commuter lines.
              </div>
            </div>

            {/* Map Legend Overlay */}
            <div className="absolute bottom-3 left-3 z-20 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl px-3 py-2 text-[11px] space-y-1 shadow-lg hidden sm:block">
              <div className="font-semibold text-slate-200 text-[10px] uppercase">Map Legend</div>
              <div className="flex items-center gap-2 text-slate-300">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500" /> Route 1 (Metro)
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ml-1" /> Route 2 (Science)
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 ml-1" /> Route 3 (Hostels)
              </div>
              <div className="flex items-center gap-2 text-amber-400 pt-0.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <span>Traffic Hazard Corridor</span>
              </div>
            </div>
          </div>

          {/* Active Route Stops Sequence Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: activeRoute.color }} />
                <h3 className="font-bold text-white text-sm sm:text-base">
                  {activeRoute.name} — Live Stops
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-medium">
                {activeRoute.operatingHours} • Every {activeRoute.frequencyMin}m
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2">
              {activeRoute.stops.map(stop => (
                <div 
                  key={stop.id}
                  className="bg-slate-950/60 rounded-xl p-3 border border-slate-800 hover:border-slate-700 transition"
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-slate-400">Stop #{stop.sequence}</span>
                    <span className="text-emerald-400 font-semibold">ETA ~{stop.sequence * 3 + 1}m</span>
                  </div>
                  <div className="font-semibold text-slate-200 text-xs mt-1 truncate" title={stop.name}>
                    {stop.name}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5 truncate">
                    📍 {stop.landmark}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Col: Driver Controls / Student ETA Dashboard */}
        <div className="space-y-5">
          {/* Driver Mode Control Panel (Specially active when role is Driver or toggleable) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <Gauge className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="font-bold text-white text-sm">
                    Driver Telemetry Portal
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Transmits GPS, Speed & Occupancy every 3s
                  </p>
                </div>
              </div>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Driver Mode
              </span>
            </div>

            {/* Broadcast Toggle Button */}
            <div className="pt-1">
              <button
                id="btn-driver-broadcast-toggle"
                onClick={() => setIsDriverBroadcasting(!isDriverBroadcasting)}
                className={`w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md ${
                  isDriverBroadcasting
                    ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-600/30'
                    : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-600/30'
                }`}
              >
                {isDriverBroadcasting ? (
                  <>
                    <Square className="w-4 h-4 fill-white" />
                    <span>Stop 3-Second GPS Broadcast</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    <span>Start 3-Second GPS Broadcast</span>
                  </>
                )}
              </button>
            </div>

            {/* Driver Controls adjustment sliders */}
            <div className="space-y-3 pt-2 text-xs">
              <div>
                <div className="flex items-center justify-between text-slate-300 mb-1">
                  <span>Current Speed</span>
                  <span className="font-bold text-white font-mono">{driverSpeed} km/h</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="60"
                  value={driverSpeed}
                  onChange={(e) => setDriverSpeed(Number(e.target.value))}
                  className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-slate-300 mb-1">
                  <span>Passenger Occupancy</span>
                  <span className="font-bold text-white font-mono">{driverOccupancy} / 52 Seats</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="52"
                  value={driverOccupancy}
                  onChange={(e) => setDriverOccupancy(Number(e.target.value))}
                  className="w-full accent-indigo-500 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Active Fleet List & Stop ETAs */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <h3 className="font-bold text-white text-sm flex items-center justify-between">
              <span>Active Fleet Radar</span>
              <span className="text-xs text-slate-400 font-normal">{buses.length} online</span>
            </h3>

            <div className="space-y-2.5">
              {buses.map(bus => {
                const isSelected = bus.id === selectedBusId;
                const occPercent = Math.round((bus.occupancy / bus.capacity) * 100);
                return (
                  <div
                    key={bus.id}
                    onClick={() => handleCenterBus(bus)}
                    className={`rounded-xl p-3.5 border transition cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800/90 border-indigo-500 ring-1 ring-indigo-500/40'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: bus.routeColor }} />
                        <span className="font-bold text-xs text-white">{bus.busNumber}</span>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        bus.status === 'ON_TIME' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {bus.status === 'ON_TIME' ? 'On Schedule' : 'Traffic Delay'}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-2 text-[11px] text-slate-300">
                      <div>
                        <span className="text-slate-500">Next: </span>
                        <strong className="text-slate-200">{bus.nextStopName}</strong>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-500">ETA: </span>
                        <strong className="text-cyan-400">~{bus.etaNextStopMin} min</strong>
                      </div>
                    </div>

                    {/* Occupancy bar */}
                    <div className="mt-2.5">
                      <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                        <span>Crowd Density ({occPercent}%)</span>
                        <span>{bus.occupancy}/{bus.capacity} Passengers</span>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${
                            occPercent > 80 ? 'bg-rose-500' : occPercent > 50 ? 'bg-amber-500' : 'bg-emerald-500'
                          }`}
                          style={{ width: `${occPercent}%` }}
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
