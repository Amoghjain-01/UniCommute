import React from 'react';
import { 
  Bus, 
  ShieldCheck, 
  MapPin, 
  Car, 
  Clock, 
  BookOpen, 
  Radio, 
  Database, 
  UserCheck, 
  QrCode,
  ArrowLeft,
  GraduationCap
} from 'lucide-react';
import { UserProfile, UserRole, ActiveFeatureView } from '../types';

interface NavbarProps {
  currentView: ActiveFeatureView;
  onSelectView: (view: ActiveFeatureView) => void;
  currentUser: UserProfile;
  onRoleChange: (role: UserRole) => void;
  onOpenIdScanner: () => void;
  isWsConnected: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onSelectView,
  currentUser,
  onRoleChange,
  onOpenIdScanner,
  isWsConnected
}) => {
  return (
    <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-8 py-3 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Brand & Back button */}
        <div className="flex items-center gap-3">
          {currentView !== 'HOME_PORTAL' && (
            <button
              id="btn-nav-back-home"
              onClick={() => onSelectView('HOME_PORTAL')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 transition"
              title="Return to Home Dashboard"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Hub</span>
            </button>
          )}

          <div 
            className="flex items-center gap-2.5 cursor-pointer select-none"
            onClick={() => onSelectView('HOME_PORTAL')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-white/20">
              <Bus className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-indigo-200 bg-clip-text text-transparent">
                  UniCommute
                </span>
                <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Campus 2.0
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden md:block">
                Smart Transit • Traffic Consensus • Delay Verification
              </p>
            </div>
          </div>
        </div>

        {/* Live sync & Role Switcher */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* WebSocket Status indicator */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800/80 border border-slate-700/60 text-[11px]">
            <span className={`w-2 h-2 rounded-full ${isWsConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span className="text-slate-300 hidden sm:inline">{isWsConnected ? 'Live Real-time' : 'Connected'}</span>
          </div>

          {/* Institutional ID Scan trigger */}
          <button
            id="btn-scan-student-id"
            onClick={onOpenIdScanner}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-500/30 text-indigo-300 hover:text-indigo-100 text-xs font-medium transition"
            title="Scan or Verify Institutional ID Card"
          >
            <QrCode className="w-4 h-4 text-indigo-400" />
            <span className="hidden md:inline">ID Badge</span>
            {currentUser.verifiedIdCard && (
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            )}
          </button>

          {/* Quick Role Toggle Bar */}
          <div className="flex items-center bg-slate-800/90 rounded-lg p-0.5 border border-slate-700 text-xs">
            <button
              id="role-btn-student"
              onClick={() => onRoleChange('student')}
              className={`px-2.5 py-1 rounded-md font-medium transition flex items-center gap-1 ${
                currentUser.role === 'student'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Student</span>
            </button>

            <button
              id="role-btn-faculty"
              onClick={() => onRoleChange('faculty')}
              className={`px-2.5 py-1 rounded-md font-medium transition flex items-center gap-1 ${
                currentUser.role === 'faculty'
                  ? 'bg-purple-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Faculty</span>
            </button>

            <button
              id="role-btn-driver"
              onClick={() => onRoleChange('driver')}
              className={`px-2.5 py-1 rounded-md font-medium transition flex items-center gap-1 ${
                currentUser.role === 'driver'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Bus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Driver</span>
            </button>
          </div>

          {/* Active Profile Info */}
          <div className="flex items-center gap-2 pl-1 border-l border-slate-800">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-8 h-8 rounded-full object-cover ring-2 ring-indigo-500/40"
              referrerPolicy="no-referrer"
            />
            <div className="hidden lg:block text-left">
              <div className="text-xs font-semibold text-slate-200 leading-tight">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-slate-400 font-mono">
                {currentUser.institutionalId}
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
