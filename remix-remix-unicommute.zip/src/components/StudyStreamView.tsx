import React, { useState } from 'react';
import { 
  Radio, 
  BookOpen, 
  Play, 
  Pause, 
  Headphones, 
  Download, 
  ThumbsUp, 
  FileText, 
  Sparkles, 
  Users, 
  Clock, 
  Plus, 
  Send,
  MessageSquare,
  Bookmark,
  CheckCircle2
} from 'lucide-react';
import { LiveStreamSession, StudyResource, UserProfile } from '../types';
import confetti from 'canvas-confetti';

interface StudyStreamViewProps {
  stream: LiveStreamSession;
  resources: StudyResource[];
  currentUser: UserProfile;
  onUploadResource: (resource: Partial<StudyResource>) => void;
}

export const StudyStreamView: React.FC<StudyStreamViewProps> = ({
  stream,
  resources,
  currentUser,
  onUploadResource
}) => {
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'TRANSCRIPT' | 'AI_NOTES' | 'COMMUTE_CHAT'>('AI_NOTES');
  const [audioModeOnly, setAudioModeOnly] = useState<boolean>(false);
  const [selectedCourseFilter, setSelectedCourseFilter] = useState<string>('ALL');

  // Commuter Live Chat State
  const [chatMessages, setChatMessages] = useState<Array<{ sender: string; time: string; text: string; role: string }>>([
    { sender: 'Devansh K. (Bus 14)', time: '09:12 AM', text: 'Stuck on Route 1 flyover, audio stream is super crisp Dr. Sen!', role: 'student' },
    { sender: 'Priya M. (Carpool #2)', time: '09:16 AM', text: 'Slide 18 on Raft Quorum is really clear.', role: 'student' },
    { sender: 'Dr. Radhika Sen (Instructor)', time: '09:20 AM', text: 'Commuter students: the quiz deadline will be extended by 45 mins due to the traffic jam.', role: 'faculty' }
  ]);
  const [newChatText, setNewChatText] = useState<string>('');

  // Upload Peer Notes Form Modal
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [noteTitle, setNoteTitle] = useState<string>('');
  const [noteCourse, setNoteCourse] = useState<string>('CS-401');
  const [noteType, setNoteType] = useState<'PDF_NOTES' | 'AUDIO_PODCAST' | 'SUMMARY_CHEAT_SHEET'>('PDF_NOTES');
  const [noteDescription, setNoteDescription] = useState<string>('');

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChatText.trim()) return;

    setChatMessages(prev => [
      ...prev,
      {
        sender: `${currentUser.name} (${currentUser.role})`,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        text: newChatText,
        role: currentUser.role
      }
    ]);
    setNewChatText('');
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim()) return;

    onUploadResource({
      courseCode: noteCourse,
      courseName: noteCourse === 'CS-401' ? 'Distributed Cloud Systems' : 'Linear Algebra & Optimization',
      title: noteTitle,
      type: noteType,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      description: noteDescription || 'Commuter student peer study guide.',
      durationOrPages: noteType === 'AUDIO_PODCAST' ? '12 min Audio' : '8 Pages PDF'
    });

    confetti({ particleCount: 50, spread: 60 });
    setShowUploadModal(false);
    setNoteTitle('');
    setNoteDescription('');
  };

  const filteredResources = selectedCourseFilter === 'ALL'
    ? resources
    : resources.filter(r => r.courseCode === selectedCourseFilter);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Radio className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Commute Lecture Stream & Study Hub
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time lecture broadcasting for delayed commuters in transit • AI Lecture Summaries • Peer Notes Repository
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setAudioModeOnly(!audioModeOnly)}
            className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border ${
              audioModeOnly
                ? 'bg-cyan-600 text-white border-cyan-500 shadow-md shadow-cyan-600/20'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
            }`}
          >
            <Headphones className="w-4 h-4" />
            <span>{audioModeOnly ? 'Audio Commute Mode ON' : 'Audio-Only Mode'}</span>
          </button>

          <button
            onClick={() => setShowUploadModal(true)}
            className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-600/20 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Notes</span>
          </button>
        </div>
      </div>

      {/* Live Lecture Video Player + Synchronized Transcripts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Columns: Video / Audio Player */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
            {/* Stream Title Bar */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-500/30">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                  LIVE BROADCAST
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {stream.courseCode} • {stream.professorName}
                </span>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Users className="w-3.5 h-3.5 text-cyan-400" />
                <span>{stream.viewerCount} Commuter Students Watching</span>
              </div>
            </div>

            {/* Video Viewport / Audio Commute Mode View */}
            <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
              {audioModeOnly ? (
                <div className="text-center p-8 space-y-3">
                  <div className="w-16 h-16 rounded-full bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mx-auto animate-pulse">
                    <Headphones className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-white font-bold text-sm">Low-Bandwidth Commuter Audio Active</h4>
                    <p className="text-xs text-slate-400 mt-1">Saving cellular data while transit tracking runs in background.</p>
                  </div>
                  <div className="flex items-center justify-center gap-1 text-cyan-400 text-xs font-mono pt-1">
                    <span>96 kbps Stereo HD</span>
                  </div>
                </div>
              ) : (
                <div className="relative w-full h-full">
                  <video
                    src={stream.videoPlaybackUrl}
                    controls
                    autoPlay
                    muted
                    loop
                    className="w-full h-full object-cover"
                  />
                  {/* Floating Live Badge */}
                  <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-md px-3 py-1 rounded-lg border border-slate-700 text-[11px] text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Turing Hall 102 Live Feed</span>
                  </div>
                </div>
              )}
            </div>

            {/* Topic Info */}
            <div className="space-y-1">
              <h3 className="font-bold text-white text-base sm:text-lg">{stream.topicTitle}</h3>
              <p className="text-xs text-slate-400">
                Started at {stream.startedAt} • Recorded session will be archived in the course study hub automatically.
              </p>
            </div>
          </div>
        </div>

        {/* Right 5 Columns: Synchronized AI Transcript / Notes / Chat */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl flex flex-col h-[480px]">
            {/* Tabs */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('AI_NOTES')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    activeTab === 'AI_NOTES'
                      ? 'bg-cyan-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>AI Key Notes</span>
                </button>

                <button
                  onClick={() => setActiveTab('TRANSCRIPT')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    activeTab === 'TRANSCRIPT'
                      ? 'bg-cyan-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Live Transcript</span>
                </button>

                <button
                  onClick={() => setActiveTab('COMMUTE_CHAT')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    activeTab === 'COMMUTE_CHAT'
                      ? 'bg-cyan-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Transit Chat</span>
                </button>
              </div>
            </div>

            {/* Tab Content Body */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
              {activeTab === 'AI_NOTES' && (
                <div className="space-y-3">
                  <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 space-y-2">
                    <div className="text-[11px] font-bold text-cyan-300 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" /> Live Synthesized Takeaways:
                    </div>
                    <ul className="space-y-1.5 text-slate-300">
                      {stream.aiSummaryNotes.map((note, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="text-cyan-400 font-bold">•</span>
                          <span>{note}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 space-y-2">
                    <div className="text-[11px] font-bold text-indigo-300">Key Terms Defined:</div>
                    {stream.keyDefinitions.map((def, idx) => (
                      <div key={idx} className="text-slate-300">
                        <strong className="text-white">{def.term}:</strong> {def.definition}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'TRANSCRIPT' && (
                <div className="space-y-2.5">
                  {stream.liveTranscript.map((t, idx) => (
                    <div key={idx} className="bg-slate-950/50 rounded-lg p-2.5 border border-slate-800">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                        <span className="font-bold text-cyan-300">{t.speaker}</span>
                        <span className="font-mono">{t.time}</span>
                      </div>
                      <p className="text-slate-200 leading-relaxed">{t.text}</p>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'COMMUTE_CHAT' && (
                <div className="space-y-2.5">
                  {chatMessages.map((msg, idx) => (
                    <div key={idx} className="bg-slate-950/50 rounded-lg p-2 border border-slate-800">
                      <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
                        <span className={`font-semibold ${msg.role === 'faculty' ? 'text-purple-300' : 'text-slate-300'}`}>
                          {msg.sender}
                        </span>
                        <span>{msg.time}</span>
                      </div>
                      <p className="text-slate-200">{msg.text}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Chat Input if in chat mode */}
            {activeTab === 'COMMUTE_CHAT' && (
              <form onSubmit={handleSendChat} className="flex items-center gap-2 pt-2 border-t border-slate-800">
                <input
                  type="text"
                  value={newChatText}
                  onChange={(e) => setNewChatText(e.target.value)}
                  placeholder="Ask a question or report your bus status..."
                  className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                />
                <button
                  type="submit"
                  className="p-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white transition"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Course Peer Notes Repository */}
      <div className="space-y-4 pt-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-400" />
              <span>Course Commuter Study Repository</span>
            </h2>
            <p className="text-xs text-slate-400">Download curated handouts, podcast audio episodes, and cheat sheets.</p>
          </div>

          <div className="flex items-center gap-2">
            {['ALL', 'CS-401', 'MATH-202'].map(code => (
              <button
                key={code}
                onClick={() => setSelectedCourseFilter(code)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold border transition ${
                  selectedCourseFilter === code
                    ? 'bg-slate-800 text-white border-indigo-500'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                }`}
              >
                {code}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {filteredResources.map(res => (
            <div
              key={res.id}
              className="bg-slate-900 border border-slate-800 hover:border-indigo-500/50 rounded-2xl p-5 space-y-3 shadow-lg transition flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                    {res.courseCode}
                  </span>
                  <span className="text-slate-400">{res.durationOrPages}</span>
                </div>

                <h3 className="font-bold text-white text-sm leading-snug">{res.title}</h3>
                <p className="text-xs text-slate-400 line-clamp-2">{res.description}</p>
                <div className="text-[11px] text-slate-500">By {res.authorName} • {res.uploadDate}</div>
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                <span className="flex items-center gap-1 text-slate-400">
                  <Download className="w-3.5 h-3.5" /> {res.downloadsCount} DLs
                </span>
                <button
                  onClick={() => confetti({ particleCount: 30, spread: 50 })}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold flex items-center gap-1.5 transition"
                >
                  <Download className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upload Notes Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Share Peer Study Material</h3>
              <button onClick={() => setShowUploadModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleUploadSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Resource Title</label>
                <input
                  type="text"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  placeholder="e.g. Raft Consensus Stepwise Diagrams"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Course Code</label>
                  <select
                    value={noteCourse}
                    onChange={(e) => setNoteCourse(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="CS-401">CS-401</option>
                    <option value="MATH-202">MATH-202</option>
                    <option value="ECE-210">ECE-210</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Material Type</label>
                  <select
                    value={noteType}
                    onChange={(e) => setNoteType(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="PDF_NOTES">PDF Handout</option>
                    <option value="SUMMARY_CHEAT_SHEET">Cheat Sheet</option>
                    <option value="AUDIO_PODCAST">Audio Episode</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Description / Summary</label>
                <textarea
                  rows={3}
                  value={noteDescription}
                  onChange={(e) => setNoteDescription(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                  placeholder="Key concepts covered in these notes..."
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold shadow-md shadow-indigo-600/20"
                >
                  Upload Material
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
