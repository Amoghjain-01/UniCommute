import express from "express";
import path from "path";
import http from "http";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";
import { 
  INITIAL_BUSES, 
  INITIAL_CARPOOLS, 
  INITIAL_ROUTES, 
  INITIAL_TRAFFIC_CLUSTERS, 
  INITIAL_ATTENDANCE_CLAIMS,
  INITIAL_LIVE_STREAM,
  INITIAL_STUDY_RESOURCES
} from "./src/data/mockData";
import { 
  LiveBus, 
  TrafficCluster, 
  TrafficReport, 
  CarpoolRide, 
  DelayAttendanceClaim, 
  IncidentType 
} from "./src/types";

// In-Memory Database for Fast Real-Time State
let liveBuses: LiveBus[] = [...INITIAL_BUSES];
let trafficClusters: TrafficCluster[] = [...INITIAL_TRAFFIC_CLUSTERS];
let allTrafficReports: TrafficReport[] = [];
// Populate initial reports
trafficClusters.forEach(cluster => {
  allTrafficReports.push(...cluster.reports);
});

let carpoolRides: CarpoolRide[] = [...INITIAL_CARPOOLS];
let attendanceClaims: DelayAttendanceClaim[] = [...INITIAL_ATTENDANCE_CLAIMS];
let studyResources = [...INITIAL_STUDY_RESOURCES];
let liveStream = { ...INITIAL_LIVE_STREAM };

// Helper: Great-circle distance calculation
function getDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3;
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

// Consensus Clustering Engine
// Verification criteria: 3 or more independent reports within 300 meters within 15 minutes (900,000 ms)
function evaluateTrafficConsensus(newReport: TrafficReport) {
  const FIFTEEN_MINUTES_MS = 15 * 60 * 1000;
  const PROXIMITY_THRESHOLD_METERS = 300;
  const REQUIRED_REPORTS = 3;
  const nowTime = new Date(newReport.timestampUtc).getTime();

  // Find existing cluster within 300m
  let targetCluster = trafficClusters.find(c => {
    const dist = getDistanceMeters(c.lat, c.lng, newReport.lat, newReport.lng);
    return dist <= PROXIMITY_THRESHOLD_METERS && c.incidentType === newReport.incidentType;
  });

  if (targetCluster) {
    // Add report to cluster
    targetCluster.reports.push(newReport);
    targetCluster.lastReportedAt = newReport.timestampUtc;

    // Filter reports within recent 15 minutes
    const recentReports = targetCluster.reports.filter(r => {
      const repTime = new Date(r.timestampUtc).getTime();
      return (nowTime - repTime) <= FIFTEEN_MINUTES_MS;
    });

    targetCluster.reportCount = recentReports.length;

    // Consensus rule: >= 3 reports verified
    if (recentReports.length >= REQUIRED_REPORTS) {
      targetCluster.verified = true;
      targetCluster.severity = 'CRITICAL';
      if (!targetCluster.detourSuggested) {
        targetCluster.detourSuggested = `Consensus verified (${recentReports.length} reports). Avoid ${targetCluster.locationName}. Alternate lanes advised.`;
      }
    }
  } else {
    // Create new cluster in PENDING state
    const newCluster: TrafficCluster = {
      id: `cluster-${Date.now()}`,
      incidentType: newReport.incidentType,
      lat: newReport.lat,
      lng: newReport.lng,
      locationName: newReport.locationName || 'Reported Hazard Zone',
      radiusMeters: 200,
      reportCount: 1,
      requiredReports: REQUIRED_REPORTS,
      verified: false, // Starts unverified
      reports: [newReport],
      firstReportedAt: newReport.timestampUtc,
      lastReportedAt: newReport.timestampUtc,
      affectedRoutes: ['route-blue-01', 'route-emerald-02'],
      severity: 'MEDIUM'
    };
    trafficClusters.push(newCluster);
  }
}

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws/transit' });

  app.use(express.json({ limit: '10mb' }));

  // Broadcast WebSocket message to all active clients
  function broadcast(data: object) {
    const message = JSON.stringify(data);
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  wss.on('connection', (ws) => {
    // Send initial snapshot
    ws.send(JSON.stringify({
      type: 'INITIAL_STATE',
      data: {
        buses: liveBuses,
        trafficClusters,
        carpools: carpoolRides,
        attendanceClaims,
        stream: liveStream
      }
    }));

    ws.on('message', (message) => {
      try {
        const parsed = JSON.parse(message.toString());
        if (parsed.type === 'DRIVER_GPS_TRANSMIT') {
          const { busId, lat, lng, speedKmH, headingDeg, nextStopId, nextStopName, etaNextStopMin, occupancy } = parsed.payload;
          const index = liveBuses.findIndex(b => b.id === busId);
          if (index !== -1) {
            liveBuses[index] = {
              ...liveBuses[index],
              lat,
              lng,
              speedKmH,
              headingDeg,
              nextStopId: nextStopId || liveBuses[index].nextStopId,
              nextStopName: nextStopName || liveBuses[index].nextStopName,
              etaNextStopMin: etaNextStopMin !== undefined ? etaNextStopMin : liveBuses[index].etaNextStopMin,
              occupancy: occupancy !== undefined ? occupancy : liveBuses[index].occupancy,
              lastPingUtc: new Date().toISOString(),
              isBroadcasting: true
            };
            broadcast({ type: 'BUS_UPDATED', payload: liveBuses[index] });
          }
        }
      } catch (err) {
        console.error('WebSocket parse error:', err);
      }
    });
  });

  // REST API Routes

  // 1. Transit & Routes API
  app.get('/api/transit/routes', (req, res) => {
    res.json({ success: true, routes: INITIAL_ROUTES });
  });

  app.get('/api/transit/buses', (req, res) => {
    res.json({ success: true, buses: liveBuses });
  });

  // Driver GPS transmission endpoint (alternative to WS)
  app.post('/api/transit/driver/ping', (req, res) => {
    const { busId, lat, lng, speedKmH, headingDeg, nextStopId, nextStopName, etaNextStopMin, occupancy } = req.body;
    const index = liveBuses.findIndex(b => b.id === busId);
    if (index !== -1) {
      liveBuses[index] = {
        ...liveBuses[index],
        lat: Number(lat),
        lng: Number(lng),
        speedKmH: Number(speedKmH),
        headingDeg: Number(headingDeg),
        nextStopId: nextStopId || liveBuses[index].nextStopId,
        nextStopName: nextStopName || liveBuses[index].nextStopName,
        etaNextStopMin: Number(etaNextStopMin) || liveBuses[index].etaNextStopMin,
        occupancy: Number(occupancy) || liveBuses[index].occupancy,
        lastPingUtc: new Date().toISOString(),
        isBroadcasting: true
      };
      broadcast({ type: 'BUS_UPDATED', payload: liveBuses[index] });
      res.json({ success: true, bus: liveBuses[index] });
    } else {
      res.status(404).json({ success: false, error: 'Bus not found' });
    }
  });

  // 2. Crowdsourced Traffic Consensus API
  app.get('/api/traffic/clusters', (req, res) => {
    res.json({ success: true, clusters: trafficClusters, reports: allTrafficReports });
  });

  app.post('/api/traffic/report', (req, res) => {
    const { reporterId, reporterName, reporterRole, reporterEmail, incidentType, description, lat, lng, locationName } = req.body;

    if (!incidentType || lat === undefined || lng === undefined) {
      return res.status(400).json({ success: false, error: 'Missing required incident fields' });
    }

    const newReport: TrafficReport = {
      id: `rep-${Date.now()}`,
      reporterId: reporterId || 'anon-student',
      reporterName: reporterName || 'Anonymous Campus Commuter',
      reporterRole: reporterRole || 'student',
      reporterEmail: reporterEmail || 'user@university.edu',
      incidentType: incidentType as IncidentType,
      description: description || 'Traffic delay reported by commuter',
      lat: Number(lat),
      lng: Number(lng),
      locationName: locationName || 'Campus Corridor',
      timestampUtc: new Date().toISOString()
    };

    allTrafficReports.push(newReport);
    evaluateTrafficConsensus(newReport);

    broadcast({ type: 'TRAFFIC_UPDATED', payload: { clusters: trafficClusters, latestReport: newReport } });
    res.json({ success: true, report: newReport, clusters: trafficClusters });
  });

  // 3. Carpool & Equal Split API (Strictly ₹ Indian Rupees)
  app.get('/api/carpool/rides', (req, res) => {
    res.json({ success: true, rides: carpoolRides });
  });

  app.post('/api/carpool/create', (req, res) => {
    const { driverId, driverName, driverEmail, driverRole, vehicleModel, vehiclePlate, origin, destination, departureTime, totalSeats, totalFuelCostINR, notes } = req.body;

    if (!driverName || !origin || !destination || !totalFuelCostINR || !totalSeats) {
      return res.status(400).json({ success: false, error: 'All ride details and total INR fuel cost are required' });
    }

    const seats = Number(totalSeats);
    const fuelCost = Number(totalFuelCostINR);
    // Initial per-seat price with just driver = totalCost / (1 driver + 0 riders) -> as riders join, it splits equally
    const initialPerSeatCost = Math.round(fuelCost / (seats + 1));

    const newRide: CarpoolRide = {
      id: `ride-${Date.now()}`,
      driverId: driverId || 'usr-student-01',
      driverName,
      driverEmail: driverEmail || 'user@university.edu',
      driverRole: driverRole || 'student',
      driverRating: 5.0,
      vehicleModel: vehicleModel || 'Sedan',
      vehiclePlate: vehiclePlate || 'KA-01-XX-0000',
      origin,
      destination,
      departureTime,
      totalSeats: seats,
      availableSeats: seats,
      totalFuelCostINR: fuelCost,
      perSeatCostINR: initialPerSeatCost,
      safetyPin: Math.floor(1000 + Math.random() * 9000).toString(),
      status: 'OPEN',
      notes: notes || 'University campus ride share',
      riders: []
    };

    carpoolRides.unshift(newRide);
    broadcast({ type: 'CARPOOL_UPDATED', payload: carpoolRides });
    res.json({ success: true, ride: newRide });
  });

  app.post('/api/carpool/book', (req, res) => {
    const { rideId, userId, userName, userEmail, userRole, pickupLocation, seatsBooked } = req.body;
    const ride = carpoolRides.find(r => r.id === rideId);
    if (!ride) {
      return res.status(404).json({ success: false, error: 'Carpool ride not found' });
    }

    const requestedSeats = Number(seatsBooked) || 1;
    if (ride.availableSeats < requestedSeats) {
      return res.status(400).json({ success: false, error: 'Not enough available seats in this ride' });
    }

    // Dynamic Equal Split:
    // Total cost divided among (1 driver + total riders)
    const newTotalPassengers = 1 + ride.riders.length + requestedSeats;
    const newPerSeatCost = Math.round(ride.totalFuelCostINR / newTotalPassengers);

    const newRider = {
      id: `rdr-${Date.now()}`,
      userId: userId || 'stu-current',
      userName: userName || 'Student Commuter',
      userEmail: userEmail || 'student@university.edu',
      userRole: userRole || 'student',
      seatsBooked: requestedSeats,
      farePaidINR: newPerSeatCost,
      pickupLocation: pickupLocation || ride.origin,
      bookedAt: new Date().toISOString()
    };

    ride.riders.push(newRider);
    ride.availableSeats -= requestedSeats;
    ride.perSeatCostINR = newPerSeatCost;
    
    // Update previous riders' split share to show true equal split!
    ride.riders.forEach(r => {
      r.farePaidINR = newPerSeatCost;
    });

    if (ride.availableSeats <= 0) {
      ride.status = 'FULL';
    }

    broadcast({ type: 'CARPOOL_UPDATED', payload: carpoolRides });
    res.json({ success: true, ride, rider: newRider, newEqualPerSeatCostINR: newPerSeatCost });
  });

  // 4. Delay Attendance Verification API
  app.get('/api/attendance/claims', (req, res) => {
    res.json({ success: true, claims: attendanceClaims });
  });

  app.post('/api/attendance/submit', (req, res) => {
    const { 
      studentId, 
      studentName, 
      studentEmail, 
      studentInstitutionalId, 
      courseCode, 
      courseName, 
      professorId, 
      professorName, 
      classStartTime, 
      capturedTimestampUtc, 
      capturedGps, 
      locationAddress, 
      recordedVideoUrl, 
      capturedPhotoBase64, 
      estimatedDelayMin, 
      excuseReason 
    } = req.body;

    // Calculate proximity to verified traffic incidents
    let trafficScore = 15; // baseline
    let nearestHazard: any = null;

    if (capturedGps && capturedGps.lat && capturedGps.lng) {
      trafficClusters.forEach(cluster => {
        const dist = getDistanceMeters(capturedGps.lat, capturedGps.lng, cluster.lat, cluster.lng);
        if (dist <= 1500) {
          // Within 1.5km of incident
          let score = cluster.verified ? 95 : 60;
          if (dist < 300) score = cluster.verified ? 99 : 75;
          if (score > trafficScore) {
            trafficScore = score;
            nearestHazard = {
              clusterId: cluster.id,
              incidentType: cluster.incidentType,
              distanceMeters: dist,
              locationName: cluster.locationName
            };
          }
        }
      });
    }

    const newClaim: DelayAttendanceClaim = {
      id: `claim-${Date.now()}`,
      studentId: studentId || 'usr-student-01',
      studentName: studentName || 'Aarav Sharma',
      studentEmail: studentEmail || 'student@university.edu',
      studentInstitutionalId: studentInstitutionalId || 'STU-2026-8942',
      courseCode: courseCode || 'CS-401',
      courseName: courseName || 'Distributed Cloud Systems',
      professorId: professorId || 'usr-fac-02',
      professorName: professorName || 'Dr. Radhika Sen',
      classStartTime: classStartTime || '09:00 AM',
      capturedTimestampUtc: capturedTimestampUtc || new Date().toISOString(),
      capturedGps: capturedGps || { lat: 12.9774, lng: 77.5877, accuracyMeters: 4.8 },
      locationAddress: locationAddress || 'Residency Road Corridor',
      recordedVideoUrl: recordedVideoUrl || 'blob:in-app-camera-recording',
      capturedPhotoBase64: capturedPhotoBase64 || '',
      estimatedDelayMin: Number(estimatedDelayMin) || 30,
      excuseReason: excuseReason || 'Route transit blockage delay',
      trafficProximityScore: trafficScore,
      nearestVerifiedHazard: nearestHazard,
      status: 'PENDING'
    };

    attendanceClaims.unshift(newClaim);
    broadcast({ type: 'ATTENDANCE_UPDATED', payload: attendanceClaims });
    res.json({ success: true, claim: newClaim });
  });

  app.post('/api/attendance/review', (req, res) => {
    const { claimId, decision, professorComment } = req.body;
    const claim = attendanceClaims.find(c => c.id === claimId);
    if (!claim) {
      return res.status(404).json({ success: false, error: 'Claim not found' });
    }

    claim.status = decision === 'APPROVE' ? 'APPROVED' : 'REJECTED';
    claim.professorDecisionComment = professorComment || (decision === 'APPROVE' ? 'Verified by instructor via GPS & traffic correlation.' : 'Insufficient transit delay justification.');
    claim.reviewedAt = new Date().toISOString();

    broadcast({ type: 'ATTENDANCE_UPDATED', payload: attendanceClaims });
    res.json({ success: true, claim });
  });

  // 5. Commute Lecture Stream & Study Hub API
  app.get('/api/stream/active', (req, res) => {
    res.json({ success: true, stream: liveStream });
  });

  app.get('/api/study/resources', (req, res) => {
    res.json({ success: true, resources: studyResources });
  });

  app.post('/api/study/resources', (req, res) => {
    const { courseCode, courseName, title, type, authorName, authorRole, durationOrPages, description, contentMarkdown } = req.body;
    const newRes = {
      id: `res-${Date.now()}`,
      courseCode: courseCode || 'CS-401',
      courseName: courseName || 'Distributed Cloud Systems',
      title: title || 'Commuter Peer Notes',
      type: type || 'PDF_NOTES',
      authorName: authorName || 'Peer Commuter',
      authorRole: authorRole || 'student',
      uploadDate: new Date().toISOString().split('T')[0],
      downloadsCount: 1,
      upvotes: 0,
      durationOrPages: durationOrPages || '4 Pages',
      description: description || 'Lecture summary notes for transit study.',
      contentMarkdown: contentMarkdown || ''
    };
    studyResources.unshift(newRes as any);
    res.json({ success: true, resource: newRes });
  });

  // 6. Supabase SQL Migrations Script Endpoint
  app.get('/api/database/schema-script', (req, res) => {
    const sqlSchema = `-- ==========================================================
-- UniCommute Supabase / PostgreSQL Production Migration Schema
-- Database tables, Real-time Subscriptions, & Edge Trigger Rules
-- ==========================================================

-- 1. Enable PostGIS & UUID extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- 2. Profiles Table (Restricted to @university.edu domains)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE CHECK (email LIKE '%@university.edu'),
  role TEXT NOT NULL CHECK (role IN ('student', 'faculty', 'driver')),
  institutional_id TEXT NOT NULL UNIQUE,
  department TEXT NOT NULL,
  verified_id_card BOOLEAN DEFAULT false,
  id_barcode TEXT,
  phone_number TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Bus Routes and Stops
CREATE TABLE IF NOT EXISTS public.bus_routes (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  color TEXT NOT NULL,
  operating_hours TEXT NOT NULL,
  frequency_min INTEGER NOT NULL DEFAULT 15,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.bus_stops (
  id TEXT PRIMARY KEY,
  route_id TEXT REFERENCES public.bus_routes(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  location GEOGRAPHY(POINT, 4326) NOT NULL,
  sequence_num INTEGER NOT NULL,
  landmark TEXT
);

-- 4. Real-time Live Fleet Telemetry (Updated every 3 seconds)
CREATE TABLE IF NOT EXISTS public.live_buses (
  id TEXT PRIMARY KEY,
  route_id TEXT REFERENCES public.bus_routes(id),
  bus_number TEXT NOT NULL,
  driver_id UUID REFERENCES public.profiles(id),
  current_location GEOGRAPHY(POINT, 4326) NOT NULL,
  speed_kmh NUMERIC(5,2) DEFAULT 0,
  heading_deg NUMERIC(5,2) DEFAULT 0,
  next_stop_id TEXT REFERENCES public.bus_stops(id),
  eta_next_stop_min INTEGER DEFAULT 5,
  capacity INTEGER DEFAULT 50,
  occupancy INTEGER DEFAULT 0,
  status TEXT DEFAULT 'ON_TIME' CHECK (status IN ('ON_TIME', 'DELAYED_TRAFFIC', 'MAINTENANCE')),
  last_ping_utc TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Traffic Incidents & Consensus Clusters
-- Edge rule: Incident verified when 3+ reports exist within 300m within 15min
CREATE TABLE IF NOT EXISTS public.traffic_clusters (
  id TEXT PRIMARY KEY,
  incident_type TEXT NOT NULL CHECK (incident_type IN ('JAM', 'ROADBLOCK', 'PROTEST', 'ACCIDENT', 'WEATHER_FLOOD', 'BUS_BREAKDOWN')),
  location GEOGRAPHY(POINT, 4326) NOT NULL,
  location_name TEXT NOT NULL,
  radius_meters INTEGER DEFAULT 300,
  report_count INTEGER DEFAULT 1,
  required_reports INTEGER DEFAULT 3,
  verified BOOLEAN DEFAULT false,
  severity TEXT DEFAULT 'MEDIUM' CHECK (severity IN ('LOW', 'MEDIUM', 'CRITICAL')),
  detour_suggested TEXT,
  first_reported_at TIMESTAMPTZ DEFAULT NOW(),
  last_reported_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.traffic_reports (
  id TEXT PRIMARY KEY,
  cluster_id TEXT REFERENCES public.traffic_clusters(id) ON DELETE SET NULL,
  reporter_id UUID REFERENCES public.profiles(id),
  incident_type TEXT NOT NULL,
  description TEXT,
  location GEOGRAPHY(POINT, 4326) NOT NULL,
  location_name TEXT,
  timestamp_utc TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Carpools with Equal Fuel/Toll Split in Indian Rupees (₹ INR)
CREATE TABLE IF NOT EXISTS public.carpool_rides (
  id TEXT PRIMARY KEY,
  driver_id UUID REFERENCES public.profiles(id),
  origin TEXT NOT NULL,
  destination TEXT NOT NULL,
  departure_time TEXT NOT NULL,
  total_seats INTEGER NOT NULL CHECK (total_seats > 0),
  available_seats INTEGER NOT NULL,
  total_fuel_cost_inr NUMERIC(10,2) NOT NULL CHECK (total_fuel_cost_inr > 0),
  per_seat_cost_inr NUMERIC(10,2) NOT NULL,
  safety_pin TEXT NOT NULL,
  status TEXT DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'FULL', 'IN_TRANSIT', 'COMPLETED', 'CANCELLED')),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.carpool_riders (
  id TEXT PRIMARY KEY,
  ride_id TEXT REFERENCES public.carpool_rides(id) ON DELETE CASCADE,
  rider_id UUID REFERENCES public.profiles(id),
  seats_booked INTEGER DEFAULT 1,
  fare_paid_inr NUMERIC(10,2) NOT NULL,
  pickup_location TEXT,
  booked_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Delay Attendance Claims (In-App Camera Proof & GPS Watermark)
CREATE TABLE IF NOT EXISTS public.delay_attendance_claims (
  id TEXT PRIMARY KEY,
  student_id UUID REFERENCES public.profiles(id),
  course_code TEXT NOT NULL,
  course_name TEXT NOT NULL,
  professor_id UUID REFERENCES public.profiles(id),
  class_start_time TEXT NOT NULL,
  captured_timestamp_utc TIMESTAMPTZ NOT NULL,
  captured_location GEOGRAPHY(POINT, 4326) NOT NULL,
  location_address TEXT NOT NULL,
  recorded_video_url TEXT,
  captured_photo_url TEXT,
  estimated_delay_min INTEGER NOT NULL,
  excuse_reason TEXT NOT NULL,
  traffic_proximity_score NUMERIC(5,2) DEFAULT 0,
  nearest_cluster_id TEXT REFERENCES public.traffic_clusters(id),
  status TEXT DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
  professor_decision_comment TEXT,
  reviewed_at TIMESTAMPTZ
);

-- 8. Real-time Replication Publication for Supabase Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.live_buses;
ALTER PUBLICATION supabase_realtime ADD TABLE public.traffic_clusters;
ALTER PUBLICATION supabase_realtime ADD TABLE public.carpool_rides;
ALTER PUBLICATION supabase_realtime ADD TABLE public.delay_attendance_claims;
`;
    res.setHeader('Content-Type', 'text/plain');
    res.send(sqlSchema);
  });

  // Vite middleware for development vs static build
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`UniCommute Server active at http://localhost:${PORT}`);
  });
}

startServer();
